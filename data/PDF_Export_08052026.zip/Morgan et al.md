\title{
MEA-4 Campaign: CCSI $^{2}$ Sequential Design of Experiments (SDoE)
}

\author{
Report prepared by: CCSI ${ }^{2}$ Team \\ Joshua C. Morgan, Benjamin Omell, Michael Matuszewski \\ National Energy Technology Laboratory, Pittsburgh PA, USA \\ Christine Anderson-Cook and Towfiq Ahmed \\ Los Alamos National Laboratory, Los Alamos NM, USA \\ Charles Tong and Brenda Ng \\ Lawrence Livermore National Laboratory, Livermore CA, USA \\ Debangsu Bhattacharyya \\ West Virginia University, Morgantown WV, USA
}

Campaign conducted June-July, 2018
CO2 Technology Centre Mongstad (TCM)

\section*{Table of Contents}
List of Figures ..... 3
List of Tables ..... 3
List of Abbreviations ..... 4
List of Variables ..... 4
Notation ..... 5
Executive Summary ..... 6
1 Background and Introduction ..... 6
2 Methodology ..... 8
2.1 Overview of Test Campaign ..... 8
2.2 Phase 1 ..... 9
2.3 Phases 2-3 ..... 9
2.3.1 Overview of SDoE Requirements ..... 9
2.3.2 Economic Optimization (Phase 2) ..... 11
2.3.3 Uncertainty Reduction throughout region (Phase 3) ..... 12
2.3.4 Bayesian Inference ..... 12
2.4 Phases 4-5 ..... 13
3 Results and Discussion ..... 13
3.1 Phase 1 ..... 13
3.2 Phase 2 ..... 15
3.3 Phase 3 ..... 16
3.4 Phases 4-5 ..... 21
4 Conclusions and Future Work ..... 26
Appendix A: Test Matrix ..... 28
142,800 ..... 59
120,000 ..... 60
150,000 ..... 61
Appendix B: Time Intervals for Steady-State Data ..... 62
Appendix C: Tabulated Experimental Data ..... 63
References ..... 68
List of Figures
Figure 1: Schematic of Bayesian SDoE applied to pilot plant test campaign ..... 7
Figure 2: Schematic for Phases 2-3 of MEA-4 Campaign ..... 10
Figure 3: Space-filling in region around optimal point for Phase 2 test plan ..... 11
Figure 4: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 1 ..... 14
Figure 5: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 2 ..... 16
Figure 6: Comparison of prior and posterior distributions of interfacial area and mass transfer model parameter ..... 19
Figure 7: Effect of first round of Bayesian inference on $\mathrm{CO}_{2}$ capture prediction confidence interval for individual points in candidate set ..... 19
Figure 8: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 3 ..... 20
Figure 9: Relationship between rich solvent flowrate and percentage error in steam requirement predicted by model for data collected in Phases 1-3 ..... 21
Figure 10: Comparison of SRD data for Phase 4 with SRD curves predicted by original model and model with consideration of steam flowrate discrepancy ..... 23
Figure 11: Comparison of data and model prediction of required L:G mass ratio for $85 \% \mathrm{CO}_{2}$ capture as a function of lean solvent loading and gas flowrate (12 m absorber) ..... 24
Figure 12: Parity plot for $\mathrm{CO}_{2}$ capture percentage for Phases 4-5 ..... 25
Figure 13: Comparison of SRD data ( $\mathrm{G}=45,000 \mathrm{sm}^{3} / \mathrm{hr}$ ) for Phase 5 with SRD curves predicted by original model and models with consideration of discrepancy models for steam flowrate and absorber $\mathrm{CO}_{2}$ capture percentage ..... 26
List of Tables
Table 1: Phases of MEA-4 Campaign ..... 8
Table 2: Test matrix for Phase 1 design of MEA-4 campaign ..... 13
Table 3: Test matrix for Phase 2 design of MEA-4 campaign ..... 15
Table 4: Test matrix for first iteration of Phase 3 design of MEA-4 campaign ..... 17
Table 5: Test matrix for second iteration of Phase 3 design of MEA-4 campaign ..... 18
Table 6: Test matrix for Phase 4 design of MEA-4 campaign ..... 22
Table 7: Test matrix for Phase 5 design of MEA-4 campaign ..... 22
List of Abbreviations

\begin{tabular}{|l|l|}
\hline CAPEX & Capital Cost \\
\hline CCSI & Carbon Capture Simulation Initiative \\
\hline CCSI ${ }^{2}$ & Carbon Capture Simulation for Industry Impact \\
\hline CHP & Combined Heat and Power \\
\hline FOQUS & Framework for Optimization, Quantification of Uncertainty, and Surrogates \\
\hline MARS & Multivariate Adaptive Regression Splines \\
\hline MEA & Monoethanolamine \\
\hline NCCC & National Carbon Capture Center \\
\hline OPEX & Operating Cost \\
\hline OUU & Optimization Under Uncertainty \\
\hline PDF & Probability Density Function \\
\hline PSTU & Pilot Solvent Test Unit \\
\hline RFCC & Residual Fluidized Catalytic Cracker \\
\hline SDoE & Sequential Design of Experiments \\
\hline SRD & Specific Reboiler Duty \\
\hline TCM & Technology Centre Mongstad \\
\hline UQ & Uncertainty Quantification \\
\hline
\end{tabular}

\section*{List of Variables}

\begin{tabular}{|l|l|}
\hline $\alpha_{\text {lean }}$ & $\mathrm{CO}_{2}$ loading in lean solvent (mol CO2/MEA) \\
\hline $\beta_{i}$ & Coefficients used for fitting linear discrepancy models \\
\hline CAP & $\mathrm{CO}_{2}$ capture percentage in absorber \\
\hline G & Flue gas flowrate ( $\mathrm{kg} / \mathrm{hr}$ ) or ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) \\
\hline $L_{\text {lean }}$ & Lean solvent flowrate (kg/hr) \\
\hline $L_{\text {lean,calc }}$ & Model calculation for $L_{\text {lean }}$ \\
\hline $\Delta L_{\text {lean }}$ & Predicted discrepancy in $L_{\text {lean, calc }}$ \\
\hline $L_{\text {rich }}$ & Rich solvent flowrate (kg/hr) \\
\hline $\dot{m}_{C A P}$ & Mass of $\mathrm{CO}_{2}$ captured ( $\mathrm{kg} / \mathrm{hr}$ ) \\
\hline $S$ & Reboiler steam flowrate (kg/hr) \\
\hline $S_{\text {calc }}$ & Model calculation for $S$ \\
\hline $\Delta S$ & Predicted discrepancy in $S_{\text {calc }}$ \\
\hline $y_{\mathrm{CO}_{2}}$ & $\mathrm{CO}_{2}$ mole fraction in flue gas \\
\hline
\end{tabular}

\section*{Notation}

\begin{tabular}{|l|l|}
\hline $\tilde{x}$ & Vector of input variables \\
\hline $\tilde{\theta}_{1}$ & Vector of model parameters with variable uncertainty \\
\hline $\tilde{\theta}_{2}$ & Vector of model parameters with fixed uncertainty \\
\hline $\tilde{\theta}$ & Combined set of model parameters, including \\
\hline $\Omega$ & Set of feasible values for $\tilde{x}$ \\
\hline $\left(\frac{A}{P}, i, n\right)$ & Annuity factor \\
\hline $\left.C I\right|_{\tilde{\chi}^{(i)}}$ & Confidence interval calculated for a specific value of $\tilde{x}$ \\
\hline $\left\{\hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(1)}\right), \ldots, \hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(M)}\right)\right\}$ & Set of values of output variable ( $\mathrm{CO}_{2}$ capture percentage) obtained by evaluating surrogate model $\hat{y}$ for a sample of size $M$ from the distribution of $\tilde{\theta}$ at a fixed value of $\tilde{x}$ \\
\hline $F_{k}$ & $\mathrm{k}^{\text {th }}$ percentile of the set of output values $\left\{\hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(1)}\right), \ldots, \hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(M)}\right)\right\}$ \\
\hline $P\left(\tilde{\theta}_{1}\right)$ & Prior distribution of $\tilde{\theta}_{1}$ \\
\hline $P\left(\tilde{\theta}_{2}\right)$ & Fixed distribution of $\tilde{\theta}_{2}$ \\
\hline $Z$ & Plant data \\
\hline $L\left(Z \mid \tilde{\theta}_{2}^{(j)}, \tilde{\theta}_{1}\right)$ & Likelihood function of experimental data $Z$ conditioned on $\tilde{\theta}_{1}$, assuming a fixed value of the parameters $\tilde{\theta}_{2}$ \\
\hline $\pi_{j}\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}^{(j)}\right)$ & Posterior distribution of $\tilde{\theta}_{1}$ generated for a fixed value of the parameters $\tilde{\theta}_{2}$ \\
\hline $\pi\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}\right)$ & Posterior distribution of $\tilde{\theta}_{1}$ obtained from marginalization of all
$$
\pi_{j}\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}^{(j)}\right)
$$ \\
\hline $f(\theta)$ & Generic probability density function \\
\hline $p\left(\theta^{L}<\theta<\theta^{U}\right)$ & Probability that the value of parameter $\theta$ is between $\theta^{L}$ and $\theta^{U}$ \\
\hline
\end{tabular}

\section*{Executive Summary}

The United States Department of Energy's Carbon Capture Simulation for Industry Impact (CCSI ${ }^{2}$ ) is developing an approach for applying sequential design of experiments (SDoE) for testing $\mathrm{CO}_{2}$ capture technologies at bench and pilot-scale. SDoE is a broad approach to experimental design in which information obtained from data obtained during a campaign is leveraged for updating the experimental plan. In the process developed by $\mathrm{CCSI}^{2}$, a stochastic model of the process system is developed by quantifying parametric uncertainty in key input parameters (e.g. those for thermodynamic and mass transfer models in a solvent-based $\mathrm{CO}_{2}$ capture process). This uncertainty is then propagated through the model for quantification of the corresponding uncertainty in the model output (e.g. $\mathrm{CO}_{2}$ capture percentage, energy requirement) under variable operating conditions. The output prediction uncertainty is incorporated into the algorithm for selecting conditions for which to collect data. This algorithm simultaneously seeks to choose test conditions for which the model prediction of uncertainty is relatively high while ensuring that the entire space of operation is well represented. As data are collected, they are incorporated into a Bayesian inference methodology which allows the parameter distributions to be updated, resulting in reduction in the model prediction of uncertainty. The updated uncertainty is then used to modify the test plan of points for which data are to be collected.

This SDoE methodology was applied to the execution of a test campaign with MEA solvent at Technology Centre Mongstad (TCM) held during the summer of 2018 over a five-week period. In the first three weeks of this campaign, the operating conditions that were varied included the flowrates of circulated solvent, flue gas, and reboiler steam in addition to the $\mathrm{CO}_{2}$ mole fraction in the flue gas. The data obtained during this portion of the campaign were used for updating the distributions of mass transfer and interfacial area model parameters of an existing process model developed by the $\mathrm{CCSI}^{2}$ team. Over two iterations of the SDoE process, the uncertainty predicted by the model over the full input space of interest decreases by an average of $58.0 \pm 4.7 \%$. In the final two weeks, the absorber packing height was reduced and the stripper configuration was modified so that a portion of the rich solvent is bypassed before the lean-rich heat exchanger and heated in the stripper water wash. This work was focused on minimizing the specific reboiler duty (SRD) required for $85 \% \mathrm{CO}_{2}$ capture for a fixed flowrate of flue gas with $10 \% \mathrm{CO}_{2}$ by varying the solvent circulation flowrate. Due to some deviation in the model predictions from the experimental data collected during the final two weeks of the campaign, particularly with respect to operation at low solvent flowrate, discrepancy functions were fitted to account for the error.

\section*{1 Background and Introduction}

The United States Department of Energy's Carbon Capture Simulation for Industry Impact (CCSI) ${ }^{2}$ program is a collaboration among national laboratories, industrial partners, and academic institutions focused on applying a suite of computational tools and models developed as a part of its precursor program, the Carbon Capture Simulation Initiative (CCSI). A major goal of CCSI ${ }^{2}$ is to apply the open-source CCSI Toolset (available at https://github.com/CCSI-Toolset) for accelerating the development, deployment, and scaleup of novel $\mathrm{CO}_{2}$ capture technologies. A previous CCSI project involved the development of a solvent modeling framework in which uncertainty is quantified at the submodel level and propagated through the overall process model to analyze the predicted output uncertainty in key process variables such as $\mathrm{CO}_{2}$ capture percentage and energy requirement for solvent regeneration. This framework has been applied to an aqueous monoethanolamine (MEA) system, in which submodels are developed with uncertainty quantification (UQ) for stand-alone property models (viscosity, molar volume, surface tension), ${ }^{1}$ a
thermodynamic framework incorporating data from multiple sources (vapor-liquid equilibrium, heat capacity, heat of absorption), ${ }^{2}$ and process dependent models, namely mass transfer, interfacial area, and hydraulics. ${ }^{3}$ A full process model for the aqueous MEA solvent system has been developed, specifically for the Pilot Solvent Test Unit (PSTU) at the National Carbon Capture Center (NCCC) in Alabama, USA, incorporating all of the previously mentioned submodels with UQ. This model was validated with data collected at NCCC in 2014. ${ }^{4}$ Despite overall satisfactory prediction of the plant data, the model output space was insufficiently explored and some clustering was observed in the test results; specifically, the $\mathrm{CO}_{2}$ capture percentage was greater than $99 \%$ for a large number of test runs. This clustering may be attributed to the experimental design methodology, in which test points were selected through a spacefilling approach based on the set of input variables (flowrates of solvent, flue gas, and reboiler steam) without consideration of the characteristics of the output space.

In order to improve upon the experimental design for future $\mathrm{CCSI}^{2}$ campaigns testing $\mathrm{CO}_{2}$ capture technologies, a new methodology based on Bayesian experimental design ${ }^{5}$ has been proposed. This approach incorporates a priori knowledge of the process, as characterized by a stochastic process model with submodel parameters represented by prior probability distributions. This process, referred to as sequential design of experiments (SDoE) in this work, is represented schematically in Figure 1.
![](https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-07.jpg?height=424&width=1628&top_left_y=1117&top_left_x=244)

\section*{Figure 1: Schematic of Bayesian SDoE applied to pilot plant test campaign}

In Bayesian SDoE, the existing process model is used to select an initial test plan (a set of experimental runs) based on some optimality criteria, which are chosen by the user to match the overall goals of the experimental campaign. For instance, it is often desirable to reduce the model prediction uncertainty through collection of new plant data, and thus it could be advantageous to prioritize data collection in process operation regimes for which the model currently predicts with high uncertainty. The prioritization of points with high uncertainty is based on the concept of G-optimality, which seeks to minimize the maximum prediction variance over the full input space. ${ }^{6}$ Moreover, these criteria could incorporate a space-filling approach, often used in design of experiments for pilot plant campaigns in order to ensure the full operating space of interest for the process is well-represented in the data. The whole pilot campaign consists of tests selected in a batch-wise manner based on the optimality criteria. The resulting experimental data from each batch are incorporated into a Bayesian inference methodology which produces posterior parameter distributions which sequentially update the model as additional batches are executed. As the model parameters are updated, the estimation of model uncertainty over the operating space is also likely to change and the modified stochastic model is used to guide and improve the test plan for the next iteration of the SDoE process. This methodology was implemented at NCCC in a
new MEA test campaign in the summer of $2017,^{7,8}$ and an average reduction of $67.2 \pm 11.6 \%$ in the width of response confidence intervals across the entire input space of interest was demonstrated for the predicted $\mathrm{CO}_{2}$ capture percentage in the absorber column.

In this work, the existing process model was modified to represent the Technology Centre Mongstad (TCM) configuration in preparation for a new SDoE demonstration at TCM, which was performed during the MEA-4 test campaign held over five weeks during June-July 2018. In addition to the SDoE procedure depicted in Figure 1 for which the goal is to reduce the uncertainty in an existing stochastic model, some additional tasks were included related to studying the effect of variation in absorber packing height and stripper configuration on the process performance. Moreover, the campaign also included additional work focused on identifying conditions of optimal operation in terms of the energy requirement and an economic objective function.

\section*{2 Methodology}

\subsection*{2.1 Overview of Test Campaign}

The MEA-4 test campaign was divided into five phases, which are characterized in Table 1.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 1: Phases of MEA-4 Campaign}
\begin{tabular}{|l|l|l|l|}
\hline Phase No. & Absorber Packing Height (m) & Stripper Configuration & Description of Criterion \\
\hline 1 & 24 & Simple & Space-filling design for testing predictability of existing model \\
\hline 2 & 24 & Simple & Selection of test points based on economic objective function \\
\hline 3 & 24 & Simple & Sequential DoE - Selection of points based on Goptimality \\
\hline 4 & 18 & With Bypass & Minimization of specific reboiler duty \\
\hline 5 & 12 & With Bypass & Minimization of specific reboiler duty \\
\hline
\end{tabular}
\end{table}

For the first three weeks of the test campaign (Phases 1-3), the absorber was operated with three packing beds, for a total height of 24 m , and a simple stripper configuration, in which the entire flow of rich solvent enters the top of the stripper. Although the flue gas from the combined heat and power (CHP) plant was used for the campaign, the process was operated with the larger stripper designed for use with flue gas from the residual fluidized catalytic cracker (RFCC) unit. The details of these three distinct phases are discussed in the forthcoming sections. Phases 4 and 5 represent an extension of the test campaign, which was originally scheduled for a three-week period, and the absorber column was operated with two beds ( 18 m total packing height) or one bed ( 12 m total packing height), respectively. In addition, the process configuration was modified in these final phases, with a portion of the cold rich solvent bypassed from the lean-rich heat exchanger, heated in the water wash column by the stripper overhead gas, and entering the top of the stripper column along with the remaining rich solvent. More details of Phases 4-5 are given in Section 2.4.

\subsection*{2.2 Phase 1}

The purpose of Phase 1 was to obtain initial process data to determine the accuracy of the existing process model. In order to validate the model over the full desired range of process operation, a space-filling approach based on the minimax optimization criterion was used for planning the test runs after initially identifying a set of viable candidate points from which to select. A desired region of process operation was established based on ranges of operation for flue gas flowrate, $\mathrm{CO}_{2}$ capture percentage, lean solvent $\mathrm{CO}_{2}$ loading, and $\mathrm{CO}_{2}$ fraction in flue gas as given below:

$$
\begin{aligned}
& G \in[36000-75000] \mathrm{kg} / \mathrm{hr} \\
& C A P \in[80-95] \% \\
& \alpha_{\text {lean }} \in[0.1-0.25] \mathrm{mol} \mathrm{CO}_{2} / \mathrm{MEA} \\
& y_{C O_{2}} \in\{0.08,0.10\}
\end{aligned}
$$


Note that the first three variables listed have continuous ranges whereas the $\mathrm{CO}_{2}$ fraction in flue gas is treated as a discrete variable with two possible values for which the process may be operated. A test set consisting of candidate experiments representing a unique combination of the factors $\left\{G, C A P, \alpha_{\text {lean }}\right\}$ is generated through a Quasi-Monte Carlo sampling technique. An Aspen Plus simulation is run for each combination to estimate corresponding values of additional variables: flowrates of lean ( $L_{\text {lean }}$ ) and rich ( $L_{\text {rich }}$ ) solvent, steam ( $S$ ), and captured $\mathrm{CO}_{2}\left(\dot{m}_{\text {CAP }}\right)$. In order to be included in the final candidate set, each test point must satisfy the following constraints, which are based on upper limits for the flowrate of $\mathrm{CO}_{2}$ captured and the reboiler steam requirement:

$$
\begin{gathered}
\dot{m}_{C A P}<8000 \mathrm{~kg} / \mathrm{hr} \\
S<14000 \mathrm{~kg} / \mathrm{hr}
\end{gathered}
$$


From the final candidate set, a designed experimental plan is created using a space filling approach based on the vector of input variables $\tilde{x}=\left[G S \alpha_{\text {lean }}\right]$. It should be noted that this analysis was performed separately for cases with variable $\mathrm{CO}_{2}$ concentration in the flue gas, while other variables, such as operating temperatures and pressures were held constant. Separate optimal designs were created for $y_{\mathrm{CO}_{2}}=0.08$ and $y_{\mathrm{CO}_{2}}=0.10$ although only the $8 \% \mathrm{CO}_{2}$ in flue gas case was implemented due to time constraints.

\subsection*{2.3 Phases 2-3}

\subsection*{2.3.1 Overview of SDoE Requirements}

Phases 2-3 focused on the sequential portion of the design of experiments plan, in which data were collected for updating the process model and guiding the test plan for further data collection. A schematic of the work flow for Phases 2-3 is given in Figure 2.
![](https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-10.jpg?height=751&width=1576&top_left_y=270&top_left_x=259)

\section*{Figure 2: Schematic for Phases 2-3 of MEA-4 Campaign}

As shown in Figure 2, the requirements for initiating SDoE include a process model that gives the outputs of interest as a function of input variables ( $\tilde{x}$ ) and prior distributions for two groups of parameters, which are denoted as $\tilde{\theta}_{1}$ and $\tilde{\theta}_{2}$. The distinction between these two groups is that the distributions of parameters included in $\tilde{\theta}_{1}$ may be updated as data are collected whereas the parameters included in $\tilde{\theta}_{2}$ are assumed to be of constant uncertainty and so are not updated. For this work, process-dependent parameters related to mass transfer and interfacial area, for which initial distributions for the MEA system were quantified in previous CCSI and $\mathrm{CCSI}^{2}$ work, ${ }^{3,7}$ are chosen for inclusion in $\tilde{\theta}_{1}$. Since these parameters were quantified at NCCC for a different absorber packing type (MELLAPAK Plus 252Y) than used in the absorber at TCM (FLEXIPAC 2X), it is necessary to update the parameter distributions through data collection, hence their inclusion in the parameter set $\tilde{\theta}_{1}$. On the other hand, thermodynamic parameter distributions were quantified independently of the values of mass transfer and interfacial area parameters, using data obtained from actual property data, including VLE data for the binary MEA- $\mathrm{H}_{2} \mathrm{O}$ system and the ternary MEA- $\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ system as well as heat capacity and heat of absorption data for the ternary system. ${ }^{2}$ Therefore, the thermodynamic model parameters are included in $\tilde{\theta}_{2}$, because these parameters are not dependent on the process equipment, and thus the process-level data are considered to be non-informative of these parameters.

While an actual Aspen Plus simulation is available, the computational complexity of this model renders it infeasible to use for many elements of the overall real-time SDoE process, especially optimization (Phase 2 ), selecting test points based on optimality criteria (Phase 3), and Bayesian inference for updating parameter distributions. To decrease the computational expense and ensure timely availability of needed information for the SDoE plan for these processes, a response surface model was developed to serve as a surrogate for the full model. The CCSI Toolset contains the capability to train various types of response surfaces. In this work, the Multivariate Adaptive Regression Splines (MARS) ${ }^{9}$ method was determined to be suitable. The surrogate model is trained based on simulation data obtained from the full space of interest for input variables and model parameters.

\subsection*{2.3.2 Economic Optimization (Phase 2)}

The Phase 2 objective for data collection was to prioritize points for which the process operation is believed to be economically optimal, in preparation for future work related to a more rigorous process optimization under uncertainty study. The objective function chosen to characterize the optimality of operating conditions was given as:

$$
\begin{equation*}
\min _{\tilde{x} \in \Omega} f(\tilde{x})=\frac{\operatorname{CAPEX}\left(\frac{A}{P}, i, n\right)+O P E X}{\dot{m}_{C A P}} \tag{1}
\end{equation*}
$$


The objective function seeks to minimize the ratio of the total annualized cost, which consists of both capital cost (CAPEX) multiplied by an annuity factor $\left(\frac{A}{P}, i, n\right)$ (with a value of approximately 0.2 ) and operating (OPEX) cost, divided by total mass of $\mathrm{CO}_{2}$ captured in the process. Here, $\Omega$ represents the set of all possible $\tilde{x}$ values for which the previously defined constraints are satisfied. Optimization of the function was performed with the choice of decision variables given as:

$$
\tilde{x}=\left[\begin{array}{c}
L_{\text {lean }}  \tag{2}\\
G \\
\alpha_{\text {lean }}
\end{array}\right]
$$


This optimization was performed separately for the cases with 8 and $10 \% \mathrm{CO}_{2}$ in flue gas. In addition to selecting the optimal point for the test plan, some additional test points in the vicinity of the optimum were included, as shown schematically in Figure 3.
![](https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-11.jpg?height=609&width=1410&top_left_y=1291&top_left_x=440)

\section*{Figure 3: Space-filling in region around optimal point for Phase 2 test plan}

As shown in Figure 3, the space surrounding the estimated optimal point can be represented as a cube created by perturbing the input variable values from their estimated optimal values by some amount, chosen as $10 \%$ for this study. While a design that permuted each factor away from this estimated optimal one at a time would require 7 test points, 6 for the center of each face of the cube (if each factor was manipulated one at a time) and 1 for the center (optimal) point, the number of test points for a given level of $y_{\mathrm{CO}_{2}}$ was reduced to 5 by considering a fractional factorial structure. Not only does this design allow for a smaller overall size of design, it also allows exploration of potential interactions between input factors around the optimum. Since two levels of $y_{\mathrm{CO}_{2}}$ were included in this analysis, the reduction of the
overall number of points required for the Phase 2 test plan was highly beneficial due to the limited amount of time available.

\subsection*{2.3.3 Uncertainty Reduction throughout region (Phase 3)}

The focus of this phase of the campaign was to prioritize data collection of points for which the estimated uncertainty, as measured by the width of confidence intervals around point estimates of the response, was relatively high. For a given point in the sample space $\left(\tilde{x}^{(i)}\right)$, a convenient measure of uncertainty is determined by estimating a $95 \%$ confidence interval for the model prediction of $\mathrm{CO}_{2}$ capture percentage. The confidence interval was estimated by taking a sample of size $M$ over the full parameter space $\left(\tilde{\theta}^{(j)}, \forall j=1, \ldots, M\right)$. Note that the parameter set $\tilde{\theta}$ is the combination of the previously defined sets of parameters $\tilde{\theta}_{1}$ and $\tilde{\theta}_{2}$. The $95 \%$ confidence interval for $\tilde{x}^{(i)}$ was estimated by:

$$
\begin{equation*}
\left.C I\right|_{\tilde{x}^{(i)}}=F_{0.975}\left(\left\{\hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(1)}\right), \ldots, \hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(M)}\right)\right\}\right)-F_{0.025}\left(\left\{\hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(1)}\right), \ldots, \hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(M)}\right)\right\}\right) \tag{3}
\end{equation*}
$$

where $\left\{\hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(1)}\right), \ldots, \hat{y}\left(\tilde{x}^{(i)}, \tilde{\theta}^{(M)}\right)\right\}$ is the set of values of $\mathrm{CO}_{2}$ capture calculated from propagating all of the individual $\tilde{\theta}^{(j)}$ through the surrogate model and $F_{k}$ represents the $k^{\text {th }}$ percentile of this set. The estimated uncertainty of the model predictions at each point in the design space was then used as a criterion for selecting points in the test campaign that reduce the overall uncertainty throughout the range of input values of interest. Accordingly, this methodology favors selection of test points $\tilde{\theta}^{(i)}$ for which the value of $\left.C I\right|_{\tilde{x}^{(i)}}$ is relatively high, while still balancing that with the space-filling aspect of test point selection for the criteria used during Phase 3. Batches of points, which matched with the time needed to update the model and identify new points to be run, used in the sequential design of experiments strategy balance good representation of design points throughout the region while making locations with large confidence interval widths more likely to be selected.

\subsection*{2.3.4 Bayesian Inference}

Data collected from both phases 2 and 3 were incorporated into the Bayesian inference framework for updating the parameter distributions. The procedure for Bayesian inference is as follows. For model parameters not updated from the newly collected data (that is, $\tilde{\theta}_{2}$ ), a sample ( $\tilde{\theta}_{2}^{(j)} ; \forall j=1, \ldots, N$ ) was drawn from their 'constant' distribution $P\left(\tilde{\theta}_{2}\right)$. For each sample point $\tilde{\theta}_{2}^{(j)}$, a posterior distribution for the remaining parameters $\left(\tilde{\theta}_{1}\right)$ is calculated:

$$
\begin{equation*}
\pi_{j}\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}^{(j)}\right) \propto P\left(\tilde{\theta}_{1}\right) L\left(Z \mid \tilde{\theta}_{2}^{(j)}, \tilde{\theta}_{1}\right) \tag{4}
\end{equation*}
$$

and given in the form of a set of sampled points. Here, $L\left(Z \mid \tilde{\theta}_{2}^{(j)}, \tilde{\theta}_{1}\right)$ represents the likelihood (some metric to express the distance between simulation and data) of observing a set of experimental data ( $Z$ ) conditioned on the values of the parameters, $P\left(\tilde{\theta}_{1}\right)$ the prior distribution of the parameters to be updated, and $\pi_{j}\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}^{(j)}\right)$ the posterior distribution of $\tilde{\theta}_{1}$ conditioned on the observed experimental data and the value of $\tilde{\theta}_{2}$ for sample $j$. Having obtained the updated $N$ individual sets of sample points that represent the individual $\pi_{j}$, the overall posterior distribution $\left(\pi\left(\tilde{\theta}_{1} \mid Z, \tilde{\theta}_{2}\right)\right)$ was obtained by combining all of the individual sets, a process called marginalization in statistics (Note: the inference step and marginalization can be combined into a single procedure to possibly reduce the overall computational
cost). The updated stochastic model (that is, the simulation model updated with 'improved' parameter distributions) may then be used for updating the test plan.

\subsection*{2.4 Phases 4-5}

The purpose of Phases 4 and 5 was to gather data for the performance of a rich solvent bypass system. In this configuration, a portion of the rich solvent exiting the absorber column is re-routed to the top of the water wash on the stripper column and heated by the vapor exiting the stripper column before entering the stripper. The purpose of this configuration is to reduce the specific reboiler duty (SRD) of the process, defined as the ratio of the energy requirement in the stripper reboiler to the total mass of $\mathrm{CO}_{2}$ captured. For these test runs, it was desired to run the process with $50,000 \mathrm{sm}^{3} / \mathrm{hr}$ of flue gas with $10 \mathrm{vol} \%$ and to capture $85 \%$ of the $\mathrm{CO}_{2}$. The absorber packing height was reduced to 18 and 12 meters for Phases 4 and 5, respectively. The total rich solvent flowrate was varied so that the value for which the SRD is minimized can be observed, and the amount of bypass was originally taken to be $20 \%$, although some variation in this amount was made while running the test campaign. This part of the test campaign was performed similarly to the 'U-curve' methodology used in previous campaigns at TCM. ${ }^{10}$

The deterministic process model is evaluated for these conditions to estimate the optimal point, and the test matrix is specified to include this point as well as additional surrounding points. As the test campaign was performed for these phases, the test plan was updated as needed based on discrepancies observed in the model fit to the data.

\section*{3 Results and Discussion}

\subsection*{3.1 Phase 1}

For Phase 1, the test plan chosen using the minimax space-filling methodology is given in Table 2. For all test runs, the $\mathrm{CO}_{2}$ concentration in the flue gas was set at $8 \mathrm{vol} \%$ and the desired value of the MEA concentration in the solvent was $30 \%$ on a $\mathrm{CO}_{2}$-free basis.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 2: Test matrix for Phase 1 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|l|}
\hline Test & Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Steam Flowrate (kg/hr) & $\mathrm{CO}_{2}$ Capture Percent Estimate \\
\hline 1A & 55,300 & 31,800 & 5,500 & 86.1 \\
\hline 1B & 54,200 & 36,000 & 7,200 & 88.0 \\
\hline 1C & 92,100 & 37,300 & 7,400 & 92.5 \\
\hline 1D & 81,400 & 43,800 & 7,700 & 84.9 \\
\hline 1E & 81,300 & 45,900 & 8,900 & 93.4 \\
\hline 1F & 120,800 & 53,700 & 10,700 & 92.2 \\
\hline 1G & 88,900 & 56,500 & 12,100 & 90.4 \\
\hline 1H & 90,300 & 57,100 & 9,800 & 82.7 \\
\hline
\end{tabular}
\end{table}

Note that the set of input variables included in the test matrix differs from those used for the space-filling design. The choice of lean flowrate, flue gas flowrate in mass units, and lean $\mathrm{CO}_{2}$ loading as the variables for the space-filling variable set was made for ease of model evaluation and updating. The values of rich solvent flowrate and steam flowrate for inclusion in the test matrix are estimated by the deterministic process model, and the flue gas flowrate was converted to volume units. In the deterministic model, all
of the thermodynamic and mass transfer model parameters were represented as point values, rather than probability distributions, so that point estimates of the output variable values could be obtained. The test matrix was organized in terms of increasing flue gas flowrate for the purpose of convenience in the process operation and to accelerate the time needed to reach steady-state conditions.

While running the plant with the specifications given in Tests 1A-1B, it was noted that the data values of $\mathrm{CO}_{2}$ capture percent were much lower than those predicted by the model. This discrepancy was attributed to the stripper performance at very low solvent flowrates, for which the reduction in the $\mathrm{CO}_{2}$ loading was substantially overestimated by the process model. Solvent maldistribution, or uneven flow through the packing, for operation at a solvent flowrate for $54,000-56,000 \mathrm{~kg} / \mathrm{hr}$ is likely a major contributor to the discrepancy between model and data; the RFCC stripper is designed to operate at nearly 4X these solvent flows which is approximately $200,000 \mathrm{~kg} / \mathrm{hr}$. As a result, the lean solvent loading for test runs 1 A and 1 B was generally higher than predicted by the data, and the $\mathrm{CO}_{2}$ capture percentage in the absorber was lower. As a solution to this issue, each of the subsequent test runs was divided into parts. First, the test was executed with the value of the steam flowrate specified in the original test matrix. After a steadystate was established, the steam flowrate was manipulated to match the estimated value of $\mathrm{CO}_{2}$ capture. Therefore, two data points were collected for each of the test runs $\mathbf{1 C}-\mathbf{1 H}$. Parity plots for the data and model estimation of the $\mathrm{CO}_{2}$ capture percentage in the absorber and the steam requirement in the stripper are given in Figure 4.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-14.jpg?height=600&width=1605&top_left_y=1209&top_left_x=262}
\captionsetup{labelformat=empty}
\caption{Figure 4: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 1.}
\end{figure}

As shown in Figure 4A, the deterministic model predicts the $\mathrm{CO}_{2}$ capture within $\pm 10 \%$ error for all data points; this is indicated in the figure by the dashed lines which encompass all data points. The average error for percentage $\mathrm{CO}_{2}$ capture is $-2.51 \pm 2.29 \%$, and the negative error indicates that the model generally underpredicts the data. For the stripper model prediction of steam requirement, the average error is estimated to be $-10.83 \pm 10.82 \%$. As shown in Figure 4B, the stripper model prediction of steam requirement is notably worse for cases in which the rich solvent flowrate is low. When the solvent flowrate is less that $90,000 \mathrm{~kg} / \mathrm{hr}$, the average error in steam requirement prediction is $-16.43 \pm 8.49 \%$, and this value is $-3.67 \pm 9.29 \%$ when the solvent flowrate is greater than $90,000 \mathrm{~kg} / \mathrm{hr}$. This discrepancy was also noted in the later phases of the test campaign, and discussion of its potential sources is forthcoming.

\subsection*{3.2 Phase 2}

Based on the adequate model accuracy demonstrated in the first phase of this project and the limited time available for planning the test runs, the model was not updated before proceeding with Phase 2. Had major biases between model and data been identified from the initial phase of test runs, correcting this discrepancy before using the model for optimization would have been highly recommended. The majority of data for Phase 2 were actually collected after those for Phase 3 due to scheduling convenience; the order of all tests can be found in the test matrix given in Appendix A. The optimization problem was performed separately for 8 and $10 \mathrm{~mol} \% \mathrm{CO}_{2}$ in the flue gas and the previously described space-filling approach was used to select the additional test points. The test matrix for this phase is given in Table 3.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 3: Test matrix for Phase 2 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|l|}
\hline Test & Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Steam Flowrate (kg/hr) & $\mathrm{CO}_{2}$ vol\% in Flue Gas \\
\hline 2A & 107,800 & 40,800 & 10,700 & 10 \\
\hline 2B & 107,100 & 44,100 & 10,300 & 8 \\
\hline 2C & 107,100 & 44,100 & 12,500 & 8 \\
\hline 2D & 97,400 & 49,000 & 11,400 & 8 \\
\hline 2E & 87,700 & 53,900 & 10,300 & 8 \\
\hline 2F & 87,700 & 53,900 & 12,500 & 8 \\
\hline 2G & 97,000 & 44,900 & 11,800 & 10 \\
\hline 2H & 97,000 & 44,900 & 9,600 & 10 \\
\hline 21 & 118,600 & 36,700 & 9,600 & 10 \\
\hline NA & 118,600 & 36,700 & 11,800 & 10 \\
\hline
\end{tabular}
\end{table}

In Table 3, the estimated optimal points for the $8 \%(2 \mathrm{~A})$ and $10 \% \mathrm{CO}_{2}(2 \mathrm{D})$ in flue gas cases are highlighted. The original optimization problem was solved with lean solvent flowrate, flue gas flowrate, and lean $\mathrm{CO}_{2}$ loading as decision variables, and the process model was used to convert to the variables used in the TCM test matrix. Additional test points were selected by perturbing the variables by $\pm 10 \%$ from the optimal values as previously described in Figure 3. Note that test 2A was performed after the first iteration of Phase 3 while the remainder of Phase 2 was performed following the conclusion of Phase 3. The test labeled 'NA' was included in the original test plan, but ultimately not performed due to time considerations; additional time was needed for process modifications required for Phase 4 following the conclusion of test 2 I . Parity plots for the $\mathrm{CO}_{2}$ capture percentage in the absorber and the steam flowrate prediction are given in Figure 5.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-16.jpg?height=598&width=1621&top_left_y=251&top_left_x=242}
\captionsetup{labelformat=empty}
\caption{Figure 5: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 2.}
\end{figure}

As shown in Figure 5, the accuracy of the model for the data collected in Phase 2 is comparable with that for Phase 1. The average percent error for the $\mathrm{CO}_{2}$ capture prediction is $-2.40 \pm 3.27 \%$, and the average percent error for the steam requirement prediction is $-5.28 \pm 8.00 \%$. The percentage error for the steam requirement prediction is substantially lower for the data collected in Phase 2 than for those collected in Phase 1. This is likely due to the inclusion of operating points with low solvent flowrate in Phase 1 and the lack thereof in Phase 2, for which the focus of data collection shifted from a space-filling approach to an optimization approach. Therefore, the model was shown to be relatively accurate for the region of the input space in which the process operation is likely to be optimal.

\subsection*{3.3 Phase 3}

As discussed previously, the goal of Phase 3 is to implement SDoE, in which future test conditions are strategically chosen based on an updated model utilizing data collected early in the experiment, with the goal of using experimental data to refine the stochastic model of the process by reducing model uncertainty. From the test selection algorithm, the first set of test runs chosen is given in Table 4. Note that the designs were created separately for the cases with 8 and $10 \mathrm{~mol} \% \mathrm{CO}_{2}$ in the flue gas.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 4: Test matrix for first iteration of Phase 3 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|l|l|}
\hline Test & Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Steam Flowrate (kg/hr) & $\mathrm{CO}_{2}$ vol\% in Flue Gas & $\mathrm{CO}_{2}$ Capture Percent Estimate \\
\hline 3A & 133,900 & 62,600 & 11,600 & 8 & 85.9 \\
\hline 3B & 115,400 & 62,300 & 10,700 & 8 & 81.3 \\
\hline 3C & 111,900 & 59,100 & 11,100 & 8 & 89.3 \\
\hline 3D & 120,200 & 56,100 & 10,100 & 8 & 84.1 \\
\hline 3E & 119,500 & 55,000 & 9,900 & 8 & 83.6 \\
\hline 3F & 81,500 & 51,100 & 10,300 & 8 & 90.1 \\
\hline 3G & 57,500 & 42,500 & 8,700 & 8 & 81.8 \\
\hline 3H & 39,300 & 30,800 & 6,600 & 8 & 80.0 \\
\hline 31 & 48,300 & 30,400 & 8,200 & 10 & 80.0 \\
\hline 3J & 85,600 & 33,800 & 7,500 & 10 & 85.5 \\
\hline 3K & 103,100 & 43,000 & 9,200 & 10 & 82.2 \\
\hline NA & 78,600 & 44,400 & 10,800 & 10 & 83.5 \\
\hline NA & 112,400 & 48,200 & 10,900 & 10 & 86.4 \\
\hline NA & 113,800 & 52,100 & 10,900 & 10 & 80.5 \\
\hline NA & 114,100 & 48,400 & 10,400 & 10 & 81.6 \\
\hline NA & 129,600 & 43,800 & 10,900 & 10 & 91.7 \\
\hline NA & 141,300 & 50,000 & 11,500 & 10 & 85.2 \\
\hline
\end{tabular}
\end{table}

In Table 4, the test runs labeled 'NA' were included in the original experimental test plan, since there was uncertainty about how long it would take to collect the data and the goal was to make maximum use of time available at the test facility. These tests were ultimately not run since, as part of the SDoE plan, it was more advantageous to use an updated version of the test matrix that was made available after updating some of the model parameters by performing Bayesian inference with the first available set of data. The updated test matrix is given in Table 5.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 5: Test matrix for second iteration of Phase 3 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|l|l|}
\hline Test & Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Steam Flowrate (kg/hr) & $\mathrm{CO}_{2}$ vol\% in Flue Gas & $\mathrm{CO}_{2}$ Capture Percent Estimate \\
\hline 3L & 96,100 & 41,300 & 9,900 & 10 & 89.4 \\
\hline 3M & 94,000 & 43,500 & 11,000 & 10 & 88.8 \\
\hline 3N & 119,500 & 46,500 & 10,900 & 10 & 86.4 \\
\hline 30 & 150,300 & 48,200 & 11,500 & 10 & 85.2 \\
\hline 3P & 130,200 & 58,400 & 10,500 & 8 & 81.9 \\
\hline 3Q & 99,900 & 53,400 & 10,500 & 8 & 90.8 \\
\hline 3R & 80,800 & 51,600 & 12,900 & 8 & 88.3 \\
\hline 3S & 127,500 & 50,800 & 10,000 & 8 & 88.7 \\
\hline 3T & 121,200 & 49,300 & 9,200 & 8 & 85.2 \\
\hline 3U & 98,200 & 47,800 & 8,400 & 8 & 81.6 \\
\hline 3 V & 125,500 & 47,000 & 9,900 & 8 & 94.2 \\
\hline NA & 81,800 & 40,700 & 7,800 & 8 & 92.9 \\
\hline
\end{tabular}
\end{table}

The data collected from the updated Phase 3 test plan were used for a second update of the model parameter distributions. The probability density functions (PDF) of the mass transfer distributions are given in Figure 6, including the prior distributions and the estimated posteriors calculated using available data after the first and second rounds of Bayesian inference. The probability density represents the relative likelihood of a parameter taking on a certain value; the probability that the parameter value is between upper and lower limits ( $\theta^{L}$ and $\theta^{U}$ ) for a generic PDF ( $f(\theta)$ ) is:

$$
\begin{equation*}
p\left(\theta^{L}<\theta<\theta^{U}\right)=\int_{\theta^{L}}^{\theta^{U}} f(\theta) d \theta \tag{5}
\end{equation*}
$$


Moreover, the PDF is defined by the constraint:

$$
\begin{equation*}
\int_{-\infty}^{\infty} f(\theta) d \theta=1 \tag{6}
\end{equation*}
$$


\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-19.jpg?height=553&width=1548&top_left_y=251&top_left_x=285}
\captionsetup{labelformat=empty}
\caption{Figure 6: Comparison of prior and posterior distributions of interfacial area and mass transfer model parameter}
\end{figure}

As shown in Figure 6, uniform prior distributions were initially chosen for the two parameters that determine the performance of the absorber packing: the coefficients for the interfacial area model and the mass transfer model. The parameter space of plausible values was significantly reduced after including the data from the first round of the experimental design, with less reduction occurs in the second round. It is noted that the final posterior distribution for the interfacial area coefficient (left) has a bimodal shape, which is due to the variation in the values of the thermodynamic model parameters (for which uncertainty is held constant) used for calculating the posterior distributions of the mass transfer parameters. The effect of the parametric uncertainty on the $\mathrm{CO}_{2}$ capture percentage uncertainty is shown in Figure 7.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-19.jpg?height=794&width=1030&top_left_y=1523&top_left_x=571}
\captionsetup{labelformat=empty}
\caption{Figure 7: Effect of first round of Bayesian inference on $\mathbf{C O}_{\mathbf{2}}$ capture prediction confidence interval for individual points in candidate set}
\end{figure}

As shown in Figure 7, the uncertainty in the prediction of $\mathrm{CO}_{2}$ capture is reduced substantially as a result of the first update of the model parameters; this is shown for the approximately 140 candidate points spread throughout the input space for the process operation. Note that the candidate set number refers to a generic index representing a unique combination of input variables (liquid and gas flowrates, $\mathrm{CO}_{2}$ loading, and $\mathrm{CO}_{2}$ fraction in flue gas) that represents a candidate point in the input space. The posterior uncertainties shown in Figure 7 correspond to 'Posterior 1' for the mass transfer model parameters shown in Figure 6. The reduction of uncertainty for the second update of the model parameters was found to be negligible, and hence is not shown here. The percentage reduction in the uncertainty prediction of the model for a given point $\left(\tilde{x}^{(i)}\right)$ in the candidate set is calculated as:

$$
\begin{equation*}
100 \% \times \frac{\left[\left.C I\right|_{\tilde{x}^{(i)}}\right]_{\text {initial }}-\left[\left.C I\right|_{\tilde{x}^{(i)}}\right]_{\text {final }}}{\left[\left.C I\right|_{\tilde{x}^{(i)}}\right]_{\text {initial }}} \tag{7}
\end{equation*}
$$


The terms $\left[\left.C I\right|_{\tilde{x}^{(i)}}\right]_{\text {initial }}$ and $\left[\left.C I\right|_{\tilde{x}^{(i)}}\right]_{\text {final }}$ represent the $95 \%$ confidence interval, calculated as shown in Eq. 3, in the model prediction of $\mathrm{CO}_{2}$ capture percentage before and after updating the distributions of the parameters in the set $\tilde{\theta}_{1}$. For the full set of $\tilde{x}^{(i)}$, which is represented by all points shown in Figure 7, the average percentage reduction in the uncertainty is $58.0 \pm 4.7 \%$. The parity plots for the deterministic model prediction of $\mathrm{CO}_{2}$ capture and steam requirement are shown in Figure 8.
![](https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-20.jpg?height=591&width=1672&top_left_y=1203&top_left_x=264)

\section*{Figure 8: Parity plots for (A) CO2 capture percentage and (B) steam flowrate required for test runs performed in Phase 3.}

The average percentage error values for the model predictions of the data collected in Phase 3 are -2.91 $\pm 5.27 \%$ for $\mathrm{CO}_{2}$ capture and $-8.53 \pm 17.20 \%$ for the steam requirement. As with the data collected in Phase 1, there is more discrepancy in the stripper model for cases in which the solvent flowrate is low. The average percentage error for the steam requirement is $-31.05 \pm 17.81 \%$ for cases in which solvent flowrate is lower than $90,000 \mathrm{~kg} / \mathrm{hr}$ and $-0.27 \pm 6.04 \%$ for cases in which the solvent flowrate exceeds $90,000 \mathrm{~kg} / \mathrm{hr}$. The amount of data collected in Phase 3 is much larger than that collected in Phases 1-2, and therefore there are more data for which the discrepancy in the stripper model is large, as shown in Figure 8B. Figure 9 shows the relationship between the rich solvent flowrate and the error percentage in the prediction of the steam requirement for all data collected in Phases 1-3.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-21.jpg?height=901&width=1159&top_left_y=367&top_left_x=500}
\captionsetup{labelformat=empty}
\caption{Figure 9: Relationship between rich solvent flowrate and percentage error in steam requirement predicted by model for data collected in Phases 1-3}
\end{figure}

Since the RCC stripper was designed for a capacity of $200,000 \mathrm{~kg} / \mathrm{hr}$, it is likely that it underperforms when the process is operated far below that capacity. As shown in the figure, the model generally predicts the steam requirement to within $\pm 10 \%$ (denoted by the dashed lines) when the rich solvent flowrate is higher than $100,000 \mathrm{~kg} / \mathrm{hr}$. It is believed that substantial maldistribution occurs in the packing in the low solvent flowrate regime, which induces inefficiency in the column operation that cannot be captured by the Aspen Plus rate-based process model.

\subsection*{3.4 Phases 4-5}

The finalized test matrices for Phases 4 and 5 are presented in Tables 6-7, respectively. For these test runs, flue gas with $10 \mathrm{vol} \% \mathrm{CO}_{2}$ was used and the steam flowrate was manipulated in order to achieve $85 \% \mathrm{CO}_{2}$ capture in the absorber.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 6: Test matrix for Phase 4 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|}
\hline Test & Total Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Bypass Flowrate (kg/hr) \\
\hline 4A & 130,000 & 50,000 & 26,000 \\
\hline 4B & 125,000 & 50,000 & 25,000 \\
\hline 4C & 120,000 & 50,000 & 24,000 \\
\hline 4D & 115,000 & 50,000 & 23,000 \\
\hline 4E & 110,000 & 50,000 & 22,000 \\
\hline 4F & 105,000 & 50,000 & 21,000 \\
\hline 4G & 105,000 & 50,000 & 26,000 \\
\hline 4H & 135,000 & 50,000 & 26,000 \\
\hline 41 & 145,000 & 50,000 & 26,000 \\
\hline 4J & 155,000 & 50,000 & 26,000 \\
\hline 4K & 125,000 & 50,000 & 20,000 \\
\hline 4L & 125,000 & 50,000 & 15,000 \\
\hline 4M & 125,000 & 50,000 & 10,000 \\
\hline
\end{tabular}
\end{table}

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 7: Test matrix for Phase 5 design of MEA-4 campaign}
\begin{tabular}{|l|l|l|l|}
\hline Test & Total Rich Solvent Flowrate (kg/hr) & Flue Gas Flowrate ( $\mathrm{sm}^{3} / \mathrm{hr}$ ) & Bypass Flowrate (kg/hr) \\
\hline 5A & 110,000 & 50,000 & 26,000 \\
\hline 5B & 120,000 & 50,000 & 26,000 \\
\hline 5C & 125,000 & 50,000 & 26,000 \\
\hline 5D & 135,000 & 50,000 & 26,000 \\
\hline 5E & 150,000 & 50,000 & 26,000 \\
\hline 5F & 170,000 & 50,000 & 26,000 \\
\hline 5G & 125,000 & 50,000 & 20,000 \\
\hline 5H & 125,000 & 45,000 & 26,000 \\
\hline 51 & 135,000 & 45,000 & 26,000 \\
\hline 5J & 145,000 & 45,000 & 26,000 \\
\hline 5K & 155,000 & 45,000 & 26,000 \\
\hline 5L & 170,000 & 45,000 & 26,000 \\
\hline 5M & 142,800 & 45,000 & 19,900 \\
\hline 5N & 164,400 & 45,000 & 10,600 \\
\hline 50 & 130,000 & 45,000 & 26,000 \\
\hline 5P & 120,000 & 45,000 & 26,000 \\
\hline 5Q & 130,000 & 40,000 & 26,000 \\
\hline 5R & 140,000 & 40,000 & 26,000 \\
\hline 5S & 150,000 & 40,000 & 26,000 \\
\hline
\end{tabular}
\end{table}

For Phases 4-5, the bypass solvent flowrate was generally set around $26,000 \mathrm{~kg} / \mathrm{hr}$, the maximum value allowable for the process operation, although some variation was included in the test matrix in order to explore the effect on the energy requirement of the process. At the beginning of these phases (Tests 4A4F), the bypass was operated at $20 \%$ of the overall rich solvent flowrate. However, this baseline
convention was modified because it was not operationally feasible to use $20 \%$ bypass at solvent flowrates above $130,000 \mathrm{~kg} / \mathrm{hr}$. The data collected in Phase 4 are compared to the SRD curves generated by the full process model in Figure 10. Some discrepancy is noted in the prediction of the required steam flowrate, and it was reconciled by replacing the calculated value ( $S_{\text {calc }}$ ) with an updated value ( $\Delta S$ ), which was calculated using:

$$
\begin{gather*}
\Delta S=\beta_{0}+\beta_{1} * L_{\text {rich }}+\beta_{2} * \text { bypass percentage }  \tag{8}\\
S=S_{\text {calc }}+\max (0, \Delta S) \tag{9}
\end{gather*}
$$


The discrepancy $(\Delta S)$ was obtained from the data using a linear fit with coefficients $\beta_{i}$ with the overall rich solvent flowrate and the percentage bypass as predictor variables. The original model gives a good match to the SRD data at high values of solvent flowrate, and thus the discrepancy term was not used in the updated model at high flowrate, or when the calculated value of the discrepancy term was less than zero.
![](https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-23.jpg?height=878&width=1183&top_left_y=1078&top_left_x=483)

\section*{Figure 10: Comparison of SRD data for Phase 4 with SRD curves predicted by original model and model with consideration of steam flowrate discrepancy}

As shown in Figure 10, the SRD data match the model reasonably well when the discrepancy in the steam flowrate prediction is modeled. Some simplifications have been made for the comparison in Figure 10, such as evaluating the model at the condition of $85 \% \mathrm{CO}_{2}$ capture whereas the data naturally vary from this value slightly. Also, the model curves assume a bypass flowrate of $26,000 \mathrm{~kg} / \mathrm{hr}$, whereas this value varied in the data as shown in Table 6. For certain values of flowrate (e.g. 105,000 and $125,000 \mathrm{~kg} / \mathrm{hr}$ ), multiple data points are shown since the process was run with variation in the bypass flowrate. In the
original model, the required steam flowrate was generally underpredicted at low flowrates, which is consistent with the analysis shown in Figure 9.

For Phase 5, performed in the final week of the test campaign, the absorber packed height was reduced to 12 m and it was attempted to find the value of the overall rich solvent flowrate that results in the minimum value of SRD. At the beginning of this test phase, a flue gas of flowrate $50,000 \mathrm{sm}^{3} / \mathrm{hr}$ was used, although this value was later decreased to 45,000 , and ultimately 40,000 , due to difficulty in achieving optimal process operation that occurred when operating the absorber column with the lowest possible packing height. It was determined that the fit of the absorber model to the experimental data is less accurate for operation with 12 meters of packing than for operation with higher packing heights. This is shown in Figure 11, in which the model prediction of required $\mathrm{L}: \mathrm{G}$ ratio for $85 \% \mathrm{CO}_{2}$ capture is compared to the process data for variable lean loading and flue gas flowrate.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-24.jpg?height=824&width=1395&top_left_y=872&top_left_x=333}
\captionsetup{labelformat=empty}
\caption{Figure 11: Comparison of data and model prediction of required $L: G$ mass ratio for $\mathbf{8 5 \%} \mathrm{CO}_{2}$ capture as a function of lean solvent loading and gas flowrate ( $\mathbf{1 2 ~ m}$ absorber)}
\end{figure}

As shown in Figure 11, the model prediction of the required $\mathrm{L}: \mathrm{G}$ ratio to achieve $85 \% \mathrm{CO}_{2}$ capture is underestimated, specifically at lean loading above $0.18 \mathrm{~mol} \mathrm{CO}_{2} / \mathrm{MEA}$. Accordingly, the $\mathrm{CO}_{2}$ capture percent is overpredicted when the model is evaluated at fixed values of liquid and gas flowrates. This discrepancy may be attributed to inaccuracy of the interfacial area and mass transfer area models for representing the absorber column with 12 m of packing height. A parity plot for the prediction of $\mathrm{CO}_{2}$ capture and the experimental data for Phases 4-5 is shown in Figure 12.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-25.jpg?height=690&width=922&top_left_y=365&top_left_x=610}
\captionsetup{labelformat=empty}
\caption{Figure 12: Parity plot for $\mathbf{C O}_{\mathbf{2}}$ capture percentage for Phases 4-5}
\end{figure}

For Phase 4, the average percentage error in the $\mathrm{CO}_{2}$ capture prediction is $-1.18 \pm 2.88 \%$ whereas the value is $7.49 \pm 4.56 \%$ (representing overprediction) for Phase 5. A discrepancy model for the absorber with 12 meters of packing was developed in attempt to improve the process model prediction of the SRD. This model is of the form:

$$
\begin{gather*}
\Delta L_{\text {lean }}=\beta_{0}+\beta_{1} * \alpha_{\text {lean }}  \tag{10}\\
L_{\text {lean }}=L_{\text {lean,calc }}+\max \left(0, \Delta L_{\text {lean }}\right) \tag{11}
\end{gather*}
$$


In this model, the lean solvent flowrate required to reach a given value of $\mathrm{CO}_{2}$ capture percentage, at a fixed value of flue gas flowrate, is the variable for which the discrepancy is modeled. For the discrepancy model developed in this work, the $\mathrm{CO}_{2}$ capture percentage is fixed at $85 \%$ capture and the flue gas flowrate at $45,000 \mathrm{sm}^{3} / \mathrm{hr}$. This flue gas flowrate was chosen since it represents the largest subset of Phase 5 data. The fitting procedure was performed analogously to that of the steam flowrate discrepancy model described earlier. The fit of the SRD data for $45,000 \mathrm{sm}^{3} / \mathrm{hr}$ flue gas flowrate to the process models with and without the discrepancy term included is shown in Figure 13.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/73efaf0f-3e1f-4599-a9f2-4eb338e93c33-26.jpg?height=828&width=1114&top_left_y=350&top_left_x=517}
\captionsetup{labelformat=empty}
\caption{Figure 13: Comparison of SRD data ( $\mathrm{G}=45,000 \mathrm{sm}^{3} / \mathrm{hr}$ ) for Phase 5 with SRD curves predicted by original model and models with consideration of discrepancy models for steam flowrate and absorber $\mathbf{C O}_{\mathbf{2}}$ capture percentage}
\end{figure}

As shown in Figure 13, there is still some discrepancy between the data and model SRD predictions when the discrepancy is modeled for both absorber and stripper columns. The required steam flowrate for reaching $85 \%$ capture was generally around or above $14,000 \mathrm{~kg} / \mathrm{hr}$, which is considered the maximum value for feasible operation. Similar trends were observed for operation with 50,000 and $40,000 \mathrm{sm}^{3} / \mathrm{hr}$ flue gas. Therefore, it was not possible to definitively determine an optimal point of operation for the 12meter absorber case. However, the data collected suggest that process operation at this packing height is not desirable due to the large increase in SRD in comparison to operation with a higher packing height.

\section*{4 Conclusions and Future Work}

In conclusion, a sequential design of experiments methodology was used to conduct a pilot test campaign at TCM for an aqueous MEA solvent system. In this methodology, a stochastic model of the process was used to predict the uncertainty in key output variables, such as $\mathrm{CO}_{2}$ capture percent in the absorber, by propagating probability distributions of parameters from mass transfer and thermodynamics models through the process model. As the output uncertainty was quantified for the full space of input conditions, this information is leveraged as part of SDoE for selecting optimal conditions for which to collect new data. Through Bayesian inference, these new data were used to update distributions of the mass transfer model parameters, resulting in corresponding updates of the output uncertainty. This methodology has been shown to significantly reduce the estimated uncertainty in process variables, by an average of $58.0 \pm 4.7 \%$ over the full input space, resulting in refinements and improved estimation in the stochastic model of the system. It is important to note that this work represents one potential use of the statistical experimental design process that is currently being implemented in the CCSI Toolset, in which model parametric
uncertainty is quantified and reduced through data collection. Without quantification of uncertainty, the process may still be used for generating space-filling designs over an input space of interest, and the resulting data may be used for model refinement. The use of statistical experimental design is especially recommended for testing of novel technologies at pilot-scale, particularly those for which previous data have not been collected. Initial models of such systems are likely to have more uncertainty, both in the form and parameterization of the submodel equations, and the Bayesian SDoE procedure described in this work contains a framework for reducing this uncertainty through collection of plant data. Ongoing work is focused on implementing this SDoE process into the open-source CCSI Toolset's FOQUS (Framework for Optimization, Quantification of Uncertainty, and Surrogates) software. This will enable SDoE to be performed in a more streamlined manner, and make it more computationally efficient for use in design of pilot test campaigns.

Future work for the MEA system modeling will focus on more rigorous modeling of the functional model form uncertainties in the absorber and stripper columns. For example, it is believed that the effect of maldistribution in the stripper column is not adequately captured in the process model, and some preliminary analysis of this has been included in this work. Another potential source of uncertainty in the heat loss in the stripper column. Further analysis is needed for simultaneously quantifying the effects of the maldistribution in the packing and the heat loss in the column. Finally, the full process model will be used in an optimization under uncertainty study (OUU) in which the effect of parametric uncertainty on optimal process design and operation will be analyzed rigorously.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Appendix A: Test Matrix}
\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/24/2018 & 6/25/2018 & 6/26/2018 \\
\hline Day & & & Sun & Mon & Tue \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 1 & Phase 1 & Phase 1 \\
\hline Test ID & & & 1A & 1B & 1C1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 31,800 & 36,000 & 37,300 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 55,300 & 54,200 & 92,100 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1250 & 1250 & 920 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 5500 & 7200 & 7400 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.7 & 1.5 & 2.5 \\
\hline Target CO2 capture & & \% & 86.1 & 88 & resulting \\
\hline
\end{tabular}
\end{table}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/26/2018 & 6/26/2018 & 6/27/2018 \\
\hline Day & & & Tue & Tue & Wed \\
\hline Time & & & 13:00 & 20:00 & 1:00 \\
\hline Phase & & & Phase 1 & Phase 1 & Phase 1 \\
\hline Test ID & & & 1C2 & 1D1 & 1D2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 37,300 & 43,800 & 43,800 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 92,100 & 81,400 & 81,400 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 920 & 1000 & 1000 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 7700 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.5 & 1.9 & 1.9 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 92.5 & resulting & 84.9 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/27/2018 & 6/27/2018 & 6/27/2018 \\
\hline Day & & & Wed & Wed & Wed \\
\hline Time & & & 8:00 & 13:00 & 20:00 \\
\hline Phase & & & Phase 1 & Phase 1 & Phase 1 \\
\hline Test ID & & & 1E1 & 1E2 & 1F1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 45,900 & 45,900 & 53,700 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 81,300 & 81,300 & 120,800 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1000 & 1000 & 700 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 8900 & resulting & 10,700 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.8 & 1.8 & 2.2 \\
\hline Target CO2 capture & & \% & resulting & 93.4 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/28/2018 & 6/28/2018 & 6/28/2018 \\
\hline Day & & & Thu & Thu & Thu \\
\hline Time & & & 1:00 & 8:00 & 13:00 \\
\hline Phase & & & Phase 1 & Phase 1 & Phase 1 \\
\hline Test ID & & & 1F2 & 1G1 & 1G2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 53,700 & 56,500 & 56,500 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 120,800 & 88,900 & 88,900 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 700 & 950 & 950 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 12,100 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.2 & 1.6 & 1.6 \\
\hline Target CO2 capture & & \% & 92.2 & resulting & 90.4 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/28/2018 & 6/29/2018 & 6/29/2018 \\
\hline Day & & & Thu & Fri & Fri \\
\hline Time & & & 20:00 & 1:00 & 8:00 \\
\hline Phase & & & Phase 1 & Phase 1 & Phase 3 \\
\hline Test ID & & & 1H1 & 1H2 & 3A1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 57,100 & 57,100 & 62,600 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 90,300 & 90,300 & 133,900 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 900 & 900 & 600 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 9800 & resulting & 11,600 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.6 & 1.6 & 2.1 \\
\hline Target CO2 capture & & \% & resulting & 82.7 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/29/2018 & 6/29/2018 & 6/30/2018 \\
\hline Day & & & Fri & Fri & Sat \\
\hline Time & & & 13:00 & 20:00 & 1:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3A2 & 3B1 & 3B2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 62,600 & 62,300 & 62,300 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 133,900 & 115,400 & 115,400 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 600 & 750 & 750 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 10,700 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.1 & 1.9 & 1.9 \\
\hline Target CO2 capture & & \% & 85.9 & resulting & 81.3 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 6/30/2018 & 6/30/2018 & 6/30/2018 \\
\hline Day & & & Sat & Sat & Sat \\
\hline Time & & & 8:00 & 13:00 & 20:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3C1 & 3C2 & 3D1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 59,100 & 59,100 & 56,100 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 111,900 & 111,900 & 120,200 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 750 & 750 & 700 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 11,100 & resulting & 10,100 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.9 & 1.9 & 2.1 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & resulting & 89.3 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/1/2018 & 7/1/2018 & 7/1/2018 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Day & & & Sun & Sun & Sun \\
\hline Time & & & 1:00 & 8:00 & 13:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3D2 & 3E1 & 3E2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 56,100 & 55,000 & 55,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 120,200 & 119,500 & 119,500 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 700 & 700 & 700 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 9900 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.1 & 2.2 & 2.2 \\
\hline Target CO2 capture & & \% & 84.1 & resulting & 83.6 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/1/2018 & 7/2/2018 & 7/2/2018 \\
\hline Day & & & Sun & Mon & Mon \\
\hline Time & & & 20:00 & 1:00 & 8:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3F1 & 3F2 & 3G1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 51,100 & 51,100 & 42,500 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 81,500 & 81,500 & 57,500 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 980 & 980 & 1200 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,300 & resulting & 8700 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.6 & 1.6 & 1.4 \\
\hline Target CO2 capture & & \% & resulting & 90.1 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/2/2018 & 7/2/2018 & 7/3/2018 \\
\hline Day & & & Mon & Mon & Tue \\
\hline Time & & & 13:00 & 20:00 & 1:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3G2 & 3H1 & 3H2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 42,500 & 30,800 & 30,800 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 57,500 & 39,300 & 39,300 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1200 & 1430 & 1430 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 6600 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.4 & 1.3 & 1.3 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 81.8 & resulting & 80 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & $7 / 3 / 2018$ & $7 / 3 / 2018$ & $7 / 3 / 2018$ \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Day & & & Tue & Tue & Tue \\
\hline Time & & & 8:00 & 13:00 & 20:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3I1 & 3 I 2 & 3J1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 30,400 & 30,400 & 33,800 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 48,300 & 48,300 & 85,600 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1350 & 1350 & 950 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 8200 & resulting & 7500 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.6 & 1.6 & 2.5 \\
\hline Target CO2 capture & & \% & resulting & 80 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/4/2018 & 7/4/2018 & 7/4/2018 \\
\hline Day & & & Wed & Wed & Wed \\
\hline Time & & & 1:00 & 8:00 & 13:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3J2 & 3K1 & 3K2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 33,800 & 43,000 & 43,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 85,600 & 103,100 & 103,100 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 950 & 820 & 820 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2150 & 2150 & 2150 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 9200 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.5 & 2.4 & 2.4 \\
\hline Target CO2 capture & & \% & 85.5 & resulting & 82.2 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/4/2018 & 7/5/2018 & 7/5/2018 \\
\hline Day & & & Wed & Thu & Thu \\
\hline Time & & & 20:00 & 1:00 & 8:00 \\
\hline Phase & & & Phase 2 & Phase 2 & Phase 3 \\
\hline Test ID & & & 2A1 & 2A2 & 3L1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 40,800 & 40,800 & 41,300 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 107,800 & 107,800 & 96,100 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 800 & 800 & 890 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,700 & resulting & 9,900 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.6 & 2.6 & 2.3 \\
\hline Target CO2 capture & & \% & resulting & 95 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/5/2018 & 7/5/2018 & 7/6/2018 \\
\hline Day & & & Thu & Thu & Fri \\
\hline Time & & & 13:00 & 20:00 & 1:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3L2 & 3M1 & 3M2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 41,300 & 43,500 & 43,500 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 96,100 & 94,000 & 94,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 890 & 890 & 890 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 11,000 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.3 & 2.2 & 2.2 \\
\hline Target CO2 capture & & \% & 89.4 & resulting & 88.8 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/6/2018 & 7/6/2018 & 7/6/2018 \\
\hline Day & & & Fri & Fri & Fri \\
\hline Time & & & 8:00 & 13:00 & 20:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3N1 & 3N2 & 301 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 46,500 & 46,500 & 48,200 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 119,500 & 119,500 & 150,300 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 720 & 720 & 520 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,900 & resulting & 11,500 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.6 & 2.6 & 3.1 \\
\hline Target CO2 capture & & \% & resulting & 86.4 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/7/2018 & 7/7/2018 & 7/7/2018 \\
\hline Day & & & Sat & Sat & Sat \\
\hline Time & & & 1:00 & 8:00 & 13:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 302 & 3P1 & 3P2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 48,200 & 58,400 & 58,400 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 150,300 & 130,200 & 130,200 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 520 & 650 & 650 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 10,500 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 3.1 & 2.2 & 2.2 \\
\hline Target CO2 capture & & \% & 85.2 & resulting & 81.9 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/7/2018 & 7/8/2018 & 7/8/2018 \\
\hline Day & & & Sat & Sun & Sun \\
\hline Time & & & 20:00 & 1:00 & 8:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3Q1 & 3Q2 & 3R1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 53,400 & 53,400 & 51,600 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 99,900 & 99,900 & 80,800 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 850 & 850 & 1000 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,500 & resulting & 12,900 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.9 & 1.9 & 1.6 \\
\hline Target CO2 capture & & \% & resulting & 90.8 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/8/2018 & 7/8/2018 & 7/9/2018 \\
\hline Day & & & Sun & Sun & Mon \\
\hline Time & & & 13:00 & 20:00 & 1:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3R2 & 3S1 & 3S2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 51,600 & 50,800 & 50,800 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 80,800 & 127,500 & 127,500 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1000 & 650 & 650 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 10,000 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.6 & 2.5 & 2.5 \\
\hline Target CO2 capture & & \% & 88.3 & resulting & 88.7 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/9/2018 & 7/9/2018 & 7/9/2018 \\
\hline Day & & & Mon & Mon & Mon \\
\hline Time & & & 8:00 & 13:00 & 20:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3T1 & 3T2 & 3U1 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 49,300 & 49,300 & 47,800 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 121,200 & 121,200 & 98,200 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 700 & 700 & 850 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 9200 & resulting & 8400 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.5 & 2.5 & 2.1 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & resulting & 85.2 & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & $7 / 10 / 2018$ & $7 / 10 / 2018$ & $7 / 10 / 2018$ \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Day & & & Tues & Tues & Tues \\
\hline Time & & & 1:00 & 8:00 & 13:00 \\
\hline Phase & & & Phase 3 & Phase 3 & Phase 3 \\
\hline Test ID & & & 3U2 & 3V1 & 3V2 \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 47,800 & 47,000 & 47,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 98,200 & 125,500 & 125,500 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 850 & 700 & 700 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & 9900 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.1 & 2.7 & 2.7 \\
\hline Target CO2 capture & & \% & 81.6 & resulting & 94.2 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/10/2018 & 7/11/2018 & 7/11/2018 \\
\hline Day & & & Tues & Wed & Wed \\
\hline Time & & & 20:00 & 4:00 & 12:00 \\
\hline Phase & & & Phase 2 & Phase 2 & Phase 2 \\
\hline Test ID & & & 2B & 2C & 2D \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 44,100 & 44,100 & 49,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 8 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 107,100 & 107,100 & 97,400 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & & & \\
\hline Stripper liquid level & 8611-LT-2152 & mm & & & \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,300 & 12,500 & 11,400 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.4 & 2.4 & 2.0 \\
\hline Target CO2 capture & & \% & resulting & resulting & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/11/2018 & 7/12/2018 & 7/12/2018 \\
\hline Day & & & Wed & Thurs & Thurs \\
\hline Time & & & 20:00 & 4:00 & 12:00 \\
\hline Phase & & & Phase 2 & Phase 2 & Phase 2 \\
\hline Test ID & & & 2E & 2F & 2G \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 24 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 53,900 & 53,900 & 44,900 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 8 & 8 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 87,700 & 87,700 & 97,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & & & \\
\hline Stripper liquid level & 8611-LT-2152 & mm & & & \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 10,300 & 12,500 & 11,800 \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 1.6 & 1.6 & 2.2 \\
\hline Target CO2 capture & & \% & resulting & resulting & resulting \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/12/2018 & 7/13/2018 & 7/13/2018 \\
\hline Day & & & Thurs & Fri & Fri \\
\hline Time & & & 20:00 & 4:00 & 12:00 \\
\hline Phase & & & Phase 2 & Phase 2 & Phase 4 \\
\hline Test ID & & & 2H & 21 & 4A \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 24 & 24 & 18 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 44,900 & 36,700 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 97,000 & 118,600 & 130,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & & & 104,000 \\
\hline R/L HE bypass to stripper & & & & & 20\% \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & & & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & & & 1100 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & & & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & 9600 & 9600 & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.2 & 3.2 & 2.6 \\
\hline Target CO2 capture & & \% & resulting & resulting & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/13/2018 & 7/14/2018 & 7/14/2018 \\
\hline Day & & & Fri & Sat & Sat \\
\hline Time & & & 20:00 & 8:00 & 20:00 \\
\hline Phase & & & Phase 4 & Phase 4 & Phase 4 \\
\hline Test ID & & & 4B & 4C & 4D \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 18 & 18 & 18 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 125,000 & 120,000 & 115,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 100,000 & 96,000 & 92,000 \\
\hline R/L HE bypass to stripper & & & 20\% & 20\% & 20\% \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 25,000 & 24,000 & 23,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1100 & 1150 & 1200 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.5 & 2.4 & 2.3 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/15/2018 & 7/15/2018 & 7/16/2018 \\
\hline Day & & & Sun & Sun & Mon \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 4 & Phase 4 & Phase 4 \\
\hline Test ID & & & 4E & 4F & 4G(1) \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 18 & 18 & 18 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 110,000 & 105,000 & 105,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 88,000 & 84,000 & 89,250 \\
\hline R/L HE bypass to stripper & & & 20\% & 20\% & 15\% \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 22,000 & 21,000 & 15,750 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & & & 1150 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.2 & 2.1 & 2.1 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/16/2018 & 7/16/2018 & 7/17/2018 \\
\hline Day & & & Mon & Mon & Tues \\
\hline Time & & & 16:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 4 & Phase 4 & Phase 4 \\
\hline Test ID & & & 4G(2) & 4H & 4H rep \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 18 & 18 & 18 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 105,000 & 135,000 & 135,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 79,000 & 109,000 & 109,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 (28) & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1150 & 850 (1150) & 850 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.1 & 2.7 & 2.7 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/17/2018 & 7/18/2018 & 7/18/2018 \\
\hline Day & & & Tues & Wed & Wed \\
\hline Time & & & 20:00 & 8:00 & 20:00 \\
\hline Phase & & & Phase 4 & Phase 4 & Phase 4 \\
\hline Test ID & & & 41 & 4J & 4K \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 18 & 18 & 18 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 145,000 & 155,000 & 125,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 119,000 & 129,000 & 105,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 20,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 770 & 690 & 850 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.9 & 3.1 & 2.5 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/19/2018 & 7/19/2018 & 7/20/2018 \\
\hline Day & & & Thurs & Thurs & Fri \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 4 & Phase 4 & Phase 5 \\
\hline Test ID & & & 4L & 4M & 5A \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 18 & 18 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 125,000 & 125,000 & 110,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 110,000 & 115,000 & 84,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 15,000 & 10,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 850 & 850 & 1280 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.5 & 2.5 & 2.2 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/20/2018 & 7/21/2018 & 7/21/2018 \\
\hline Day & & & Fri & Sat & Sat \\
\hline Time & & & 20:00 & 8:00 & 20:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5B & 5C & 5D \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 120,000 & 125,000 & 135,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 94,000 & 99,000 & 109,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1240 & 1200 & 1280 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.4 & 2.5 & 2.7 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/22/2018 & 7/22/2018 & 7/23/2018 \\
\hline Day & & & Sun & Sun & Mon \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5E & 5F & 5G \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 50,000 & 50,000 & 50,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 150,000 & 170,000 & 125,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 124,000 & 144,000 & 105,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 20,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1130 & 1060 & 1200 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 3 & 3.4 & 2.5 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/23/2018 & 7/24/2018 & 7/24/2018 \\
\hline Day & & & Mon & Tues & Tues \\
\hline Time & & & 20:00 & 8:00 & 20:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5H & 51 & 5J \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 45,000 & 45,000 & 45,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 125,000 & 135,000 & 145,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 99,000 & 109,000 & 119,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1200 & 1200 & 1200 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 2.8 & 3.0 & 3.2 \\
\hline Target CO2 capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/25/2018 & 7/25/2018 & 7/26/2018 \\
\hline Day & & & Wed & Wed & Thurs \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5K & 5L & 5M \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 45,000 & 45,000 & 45,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 155,000 & 170,000 & 142,800 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 129,000 & 144,000 & 122,900 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 19,900 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1200 & 1200 & 1200 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 3.4 & 3.8 & 3.2 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/26/2018 & 7/27/2018 & 7/27/2018 \\
\hline Day & & & Thurs & Fri & Fri \\
\hline Time & & & 20:00 & 8:00 & 20:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5N & 50 & 5P \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 45,000 & 45,000 & 45,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 164,400 & 130,000 & 120,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 153,800 & 104,000 & 94,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 10,600 & 26,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1150 & 1300 & 1250 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 3.7 & 2.9 & 2.7 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|}
\hline Date & & & 7/28/2018 & 7/28/2018 & 7/29/2018 \\
\hline Day & & & Sat & Sat & Sun \\
\hline Time & & & 8:00 & 20:00 & 8:00 \\
\hline Phase & & & Phase 5 & Phase 5 & Phase 5 \\
\hline Test ID & & & 5Q & 5R & 5S \\
\hline Gas Source & & & CHP & CHP & CHP \\
\hline Stripper in Use & & & RFCC & RFCC & RFCC \\
\hline $\mathrm{CO}_{2}$ Recycle & & & yes & yes & yes \\
\hline Acid wash in operation & & & no & no & no \\
\hline Absorber packing height & & & 12 & 12 & 12 \\
\hline \multicolumn{6}{|c|}{Operational Settings} \\
\hline Flue gas flow rate into absorber & 8610-FIC-0150 & $\mathrm{sm}^{3} / \mathrm{hr}$ & 40,000 & 40,000 & 40,000 \\
\hline Flue gas $\mathrm{CO}_{2}$ concentration into absorber & 8610-AI-2004A & vol\% & 10 & 10 & 10 \\
\hline Flue gas temperature into absorber & 8610-TT-2041 & ${ }^{\circ} \mathrm{C}$ & 28 & 28 & 28 \\
\hline Flue gas temperature out of absorber & 8610-TT-2035 & ${ }^{\circ} \mathrm{C}$ & 30 & 30 & 30 \\
\hline Process fluid temperature into the upper water wash & 8610-TIC-2102 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline Process fluid temperature into the low water wash & 8610-TIC-2363 & ${ }^{\circ} \mathrm{C}$ & 50 & 50 & 50 \\
\hline Lower water wash circulation flow rate & 8610-FIC-2373 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Upper water wash circulation flow rate & 8610-FIC-2001 & kg/h & 90,000 & 90,000 & 90,000 \\
\hline Lower water wash liquid level & 8610-LT-2361 & mm & 600 & 600 & 600 \\
\hline Upper water wash liquid level & 8610-LT-2100 & mm & 600 & 600 & 600 \\
\hline pH upper water wash & & & resulting & resulting & resulting \\
\hline Lean solvent flow rate & 8611-FT-2045 & kg/h & resulting & resulting & resulting \\
\hline Total rich solvent flow & & kg/h & 130,000 & 140,000 & 150,000 \\
\hline Rich solvent flow to stripper through HE & 8611-FIC-2004 & kg/h & 104,000 & 114,000 & 124,000 \\
\hline R/L HE bypass to stripper & & & & & \\
\hline R/L HE bypass to stripper & 8611-FIC-2260 & kg/h & 26,000 & 26,000 & 26,000 \\
\hline MEA concentration & & wt\% & 30 & 30 & 30 \\
\hline Lean solvent temperature & 8611-TIC-2115 & ${ }^{\circ} \mathrm{C}$ & 35 & 35 & 35 \\
\hline Absorber liquid level & 8610-LT-2030 & mm & 1200 & 1160 & 1130 \\
\hline Stripper liquid level & 8611-LT-2152 & mm & 2070 & 2070 & 2070 \\
\hline Stripper top pressure & 8615-PIC-2163 & barg & 0.9 & 0.9 & 0.9 \\
\hline Steam flow to reboiler & 8655-FI-2158C & kg/h & resulting & resulting & resulting \\
\hline Reboiler bottom temperature & 8611-TIC-2151 & ${ }^{\circ} \mathrm{C}$ & resulting & resulting & resulting \\
\hline L/G & & $\mathrm{kg} / \mathrm{sm}^{3}$ & 3.3 & 3.5 & 3.8 \\
\hline Target $\mathrm{CO}_{2}$ capture & & \% & 85 & 85 & 85 \\
\hline
\end{tabular}

\section*{Appendix B: Time Intervals for Steady-State Data}

The time slots used for obtaining steady-state data are presented in the following tables. For each steadystate point, the values of the relevant variables are calculated by taking the average over all of the measured values (given in one-minute intervals) within the specified time period. The tests with label 'NA' are those for which steady-state data were not identified due to noisy data, and these are omitted from the data analyses presented in this work.

\begin{tabular}{|l|l|l|l|l|l|l|l|l|l|}
\hline Test No & \multicolumn{2}{|l|}{Start} & \multicolumn{2}{|l|}{End} & Test No & \multicolumn{2}{|l|}{Start} & \multicolumn{2}{|l|}{End} \\
\hline 1A & 24-Jun-18 & 16:19 & 25-Jun-18 & 00:40 & 2A1 & 04-Jul-18 & 21:39 & 04-Jul-18 & 23:20 \\
\hline 1B & 25-Jun-18 & 23:19 & 26-Jun-18 & 04:20 & 2A2 & 05-Jul-18 & 04:19 & 05-Jul-18 & 05:59 \\
\hline 1C1 & 26-Jun-18 & 09:39 & 26-Jun-18 & 11:19 & 3L1 & 05-Jul-18 & 09:39 & 05-Jul-18 & 12:10 \\
\hline 1C2 & 26-Jun-18 & 16:19 & 26-Jun-18 & 18:00 & 3L2 & 05-Jul-18 & 17:59 & 05-Jul-18 & 19:40 \\
\hline 1D1 & 26-Jun-18 & 22:29 & 27-Jun-18 & 00:10 & 3M1 & 05-Jul-18 & 23:19 & 06-Jul-18 & 01:00 \\
\hline 1D2 & 27-Jun-18 & 04:19 & 27-Jun-18 & 07:40 & 3M2 & NA & & NA & \\
\hline 1E1 & 27-Jun-18 & 09:39 & 27-Jun-18 & 11:20 & 3N1 & NA & & NA & \\
\hline 1E2 & 27-Jun-18 & 16:19 & 27-Jun-18 & 19:40 & 3N2 & 06-Jul-18 & 16:19 & 06-Jul-18 & 19:40 \\
\hline 1F1 & 27-Jun-18 & 22:29 & 28-Jun-18 & 00:59 & 301 & 06-Jul-18 & 21:39 & 07-Jul-18 & 00:59 \\
\hline 1F2 & 28-Jun-18 & 05:09 & 28-Jun-18 & 07:40 & 302 & 07-Jul-18 & 04:19 & 07-Jul-18 & 07:40 \\
\hline 1G1 & 28-Jun-18 & 11:19 & 28-Jun-18 & 13:00 & 3P1 & 07-Jul-18 & 09:39 & 07-Jul-18 & 12:10 \\
\hline 1G2 & 28-Jun-18 & 17:59 & 28-Jun-18 & 19:40 & 3P2 & 07-Jul-18 & 16:19 & 07-Jul-18 & 19:40 \\
\hline 1H1 & 28-Jun-18 & 23:19 & 29-Jun-18 & 00:59 & 3Q1 & 07-Jul-18 & 21:39 & 08-Jul-18 & 01:00 \\
\hline 1H2 & 29-Jun-18 & 04:19 & 29-Jun-18 & 06:00 & 3Q2 & 08-Jul-18 & 04:19 & 08-Jul-18 & 07:40 \\
\hline 3A1 & 29-Jun-18 & 11:19 & 29-Jun-18 & 13:00 & 3R1 & 08-Jul-18 & 09:39 & 08-Jul-18 & 13:00 \\
\hline 3A2 & 29-Jun-18 & 16:19 & 29-Jun-18 & 18:00 & 3R2 & NA & & NA & \\
\hline 3B1 & 29-Jun-18 & 21:39 & 29-Jun-18 & 23:20 & 3S1 & 08-Jul-18 & 23:19 & 09-Jul-18 & 01:00 \\
\hline 3B2 & 30-Jun-18 & 02:39 & 30-Jun-18 & 04:20 & 3S2 & 09-Jul-18 & 04:19 & 09-Jul-18 & 07:40 \\
\hline 3C1 & 30-Jun-18 & 09:39 & 30-Jun-18 & 13:00 & 3T1 & 09-Jul-18 & 09:39 & 09-Jul-18 & 13:00 \\
\hline 3C2 & 30-Jun-18 & 16:19 & 30-Jun-18 & 18:00 & 3T2 & 09-Jul-18 & 16:19 & 09-Jul-18 & 19:40 \\
\hline 3D1 & 30-Jun-18 & 21:39 & 30-Jun-18 & 23:20 & 3U1 & 09-Jul-18 & 21:39 & 10-Jul-18 & 00:10 \\
\hline 3D2 & 01-Jul-18 & 04:19 & 01-Jul-18 & 06:50 & 3U2 & 10-Jul-18 & 04:19 & 10-Jul-18 & 07:39 \\
\hline 3E1 & 01-Jul-18 & 09:39 & 01-Jul-18 & 12:50 & 3V1 & 10-Jul-18 & 10:29 & 10-Jul-18 & 13:00 \\
\hline 3E2 & 01-Jul-18 & 16:19 & 01-Jul-18 & 18:00 & 3V2 & 10-Jul-18 & 16:19 & 10-Jul-18 & 19:40 \\
\hline 3F1 & 01-Jul-18 & 21:39 & 02-Jul-18 & 00:50 & 2B & 10-Jul-18 & 23:19 & 11-Jul-18 & 02:40 \\
\hline 3F2 & 02-Jul-18 & 04:19 & 02-Jul-18 & 07:39 & 2C & 11-Jul-18 & 05:39 & 11-Jul-18 & 09:00 \\
\hline 3G1 & 02-Jul-18 & 11:19 & 02-Jul-18 & 13:00 & 2D & 11-Jul-18 & 15:19 & 11-Jul-18 & 18:40 \\
\hline 3G2 & 02-Jul-18 & 17:09 & 02-Jul-18 & 19:40 & 2E & 11-Jul-18 & 21:39 & 12-Jul-18 & 02:40 \\
\hline 3H1 & 03-Jul-18 & 00:59 & 03-Jul-18 & 02:39 & 2F & 12-Jul-18 & 05:39 & 12-Jul-18 & 10:40 \\
\hline 3H2 & 03-Jul-18 & 05:59 & 03-Jul-18 & 07:40 & 2 G & 12-Jul-18 & 16:59 & 12-Jul-18 & 18:40 \\
\hline $3 \mid 1$ & 03-Jul-18 & 11:19 & 03-Jul-18 & 13:00 & 2H & 12-Jul-18 & 23:19 & 13-Jul-18 & 01:00 \\
\hline 312 & 03-Jul-18 & 16:19 & 03-Jul-18 & 19:40 & 21 & 13-Jul-18 & 07:19 & 13-Jul-18 & 10:40 \\
\hline 3J1 & 03-Jul-18 & 23:19 & 04-Jul-18 & 01:00 & & & & & \\
\hline 3J2 & 04-Jul-18 & 04:19 & 04-Jul-18 & 07:40 & & & & & \\
\hline 3K1 & 04-Jul-18 & 09:39 & 04-Jul-18 & 13:00 & & & & & \\
\hline 3K2 & 04-Jul-18 & 17:59 & 04-Jul-18 & 19:40 & & & & & \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|l|l|l|l|}
\hline Test No & \multicolumn{2}{|l|}{Start} & \multicolumn{2}{|l|}{End} & Test No & \multicolumn{2}{|l|}{Start} & \multicolumn{2}{|l|}{End} \\
\hline 4A & 13-Jul-18 & 18:39 & 13-Jul-18 & 21:59 & 5C & 21-Jul-18 & 11:19 & 21-Jul-18 & 16:20 \\
\hline 4B & 13-Jul-18 & 23:39 & 14-Jul-18 & 04:40 & 5D & 22-Jul-18 & 05:59 & 22-Jul-18 & 07:40 \\
\hline 4C & 14-Jul-18 & 18:00 & 14-Jul-18 & 19:40 & 5E & 22-Jul-18 & 09:39 & 22-Jul-18 & 11:20 \\
\hline 4D & 15-Jul-18 & 00:59 & 15-Jul-18 & 04:20 & 5F & 23-Jul-18 & 00:59 & 23-Jul-18 & 06:00 \\
\hline 4E & 15-Jul-18 & 16:19 & 15-Jul-18 & 18:00 & 5G & 23-Jul-18 & 16:19 & 23-Jul-18 & 19:40 \\
\hline 4F & 16-Jul-18 & 02:39 & 16-Jul-18 & 07:40 & 5H & 24-Jul-18 & 04:19 & 24-Jul-18 & 07:40 \\
\hline 4G(1) & 16-Jul-18 & 12:59 & 16-Jul-18 & 14:40 & 51 & 24-Jul-18 & 14:39 & 24-Jul-18 & 16:20 \\
\hline 4G(2) & 16-Jul-18 & 18:29 & 16-Jul-18 & 19:20 & 5J & 25-Jul-18 & 02:39 & 25-Jul-18 & 07:40 \\
\hline 4H & NA & & NA & & 5K & 25-Jul-18 & 16:19 & 25-Jul-18 & 18:00 \\
\hline 4H rep & 17-Jul-18 & 16:19 & 17-Jul-18 & 19:40 & 5L & 26-Jul-18 & 04:19 & 26-Jul-18 & 07:40 \\
\hline 41 & 18-Jul-18 & 04:19 & 18-Jul-18 & 07:40 & 5M & 26-Jul-18 & 11:19 & 26-Jul-18 & 13:00 \\
\hline 4J & 18-Jul-18 & 16:19 & 18-Jul-18 & 19:40 & 5N & 27-Jul-18 & 04:19 & 27-Jul-18 & 06:00 \\
\hline 4K & 19-Jul-18 & 04:19 & 19-Jul-18 & 07:40 & 50 & 27-Jul-18 & 11:19 & 27-Jul-18 & 13:00 \\
\hline 4L & 19-Jul-18 & 17:59 & 19-Jul-18 & 19:40 & 5P & 28-Jul-18 & 02:39 & 28-Jul-18 & 06:00 \\
\hline 4M & 19-Jul-18 & 21:39 & 19-Jul-18 & 22:30 & 5Q & 28-Jul-18 & 16:19 & 28-Jul-18 & 19:40 \\
\hline 5A & 20-Jul-18 & 16:19 & 20-Jul-18 & 18:00 & 5R & 29-Jul-18 & 04:19 & 29-Jul-18 & 07:40 \\
\hline 5B & 21-Jul-18 & 05:59 & 21-Jul-18 & 07:40 & 5S & 29-Jul-18 & 16:19 & 29-Jul-18 & 19:40 \\
\hline
\end{tabular}

\section*{Appendix C: Tabulated Experimental Data}

This appendix includes definitions of process variables, both measured and calculated, as well as relevant equations. Finally, the experimental data calculated from the steady-state periods given in Appendix B are also provided. The measured and calculated values are:

\begin{tabular}{|l|l|l|l|}
\hline Name & Unit & Source: Tag Number or Equation & Description \\
\hline $T_{g, \text { inlet }}$ & ${ }^{\circ} \mathrm{C}$ & 8610-TIC-0123 & Temperature of flue gas into CHP absorber \\
\hline $P_{\text {ambient }}$ & bar & 8687-ORA-0370 & Ambient pressure \\
\hline $P_{g \text {,inlet }}$ & barg & 8610-PT-2040 & Pressure of flue gas into CHP absorber \\
\hline $\mathrm{H}_{2} \mathrm{O}_{, \text {FG inlet }}$ & mol \% & Calculated (C.1) & Water content of flue gas into CHP absorber \\
\hline $\mathrm{CO}_{2, F G \text { inlet-dry basis }}$ & mol \% & 8610-AI-2004A & Measured water content of flue gas into CHP absorber on dry basis \\
\hline $C O_{2, F G \text { inlet }}$ & $\mathrm{mol} \%$ & Calculated (C.2) & $\mathrm{CO}_{2}$ content of flue gas into CHP absorber \\
\hline $G_{\text {in }}$ & $\mathrm{sm}^{3} / \mathrm{hr}$ & 8610-FIC-0150 & Standard volumetric flowrate of CHP flue gas into absorber \\
\hline $\dot{m}_{\mathrm{CO}_{2}, F G \text { inlet }}$ & kg/hr & Calculated (C.3) & Mass flow rate of $\mathrm{CO}_{2}$ into absorber \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|}
\hline $T_{g, \text { outlet }}$ & ${ }^{\circ} \mathrm{C}$ & 8610-TT-2035 & Temperature of flue gas out of CHP absorber \\
\hline $P_{g, \text { outlet }}$ & barg & 8610-PT-2430 & Pressure of flue gas out of CHP absorber \\
\hline $\mathrm{H}_{2} \mathrm{O}_{\text {FG } \text { outlet }}$ & bar & Calculated (C.4) & Water content of flue gas out of CHP absorber \\
\hline $\mathrm{CO}_{2, \text { FG }}$ outlet-dry basis & mol \% & 8610-AI-2030A & Measured water content of flue gas out of CHP absorber on dry basis \\
\hline $\mathrm{CO}_{2, F G \text { outlet }}$ & mol \% & Calculated (C.5) & $\mathrm{CO}_{2}$ content of flue gas out of CHP absorber \\
\hline $G_{\text {out }}$ & $\mathrm{sm}^{3} / \mathrm{hr}$ & Calculated (C.6) & Standard volumetric flowrate of CHP flue gas out of absorber \\
\hline $\dot{m}_{\mathrm{CO}_{2}, F G \text { outlet }}$ & kg/hr & Calculated (C.7) & Mass flow rate of $\mathrm{CO}_{2}$ out of absorber \\
\hline CAP & \% & Calculated (C.8) & Percentage of $\mathrm{CO}_{2}$ capture in absorber \\
\hline $T_{\text {lean-hot }}$ & ${ }^{\circ} \mathrm{C}$ & 8611-TT-2110 & Solvent temperature at stripper exit \\
\hline $P_{\text {lean-hot }}$ & barg & 8611-PT-2153 & Solvent pressure at stripper exit \\
\hline $\alpha_{\text {lean }}$ & mol CO2/MEA & Calculated (C.9) & Solvent lean loading estimated by correlation \\
\hline $P_{\text {steam }}$ & barg & 8655-PIC-2161 & Reboiler inlet steam pressure \\
\hline $T_{\text {steam }}$ & ${ }^{\circ} \mathrm{C}$ & 8655-TT-2159 & Reboiler inlet steam temperature \\
\hline $H_{\text {steam }}$ & kJ/kg & Calculated (C.10) & Reboiler inlet steam enthalpy \\
\hline $P_{\text {condensate }}$ & barg & 8655-PT-2168 & Reboiler outlet condensate pressure \\
\hline $T_{\text {condensate }}$ & ${ }^{\circ} \mathrm{C}$ & 8655-TT-2160 & Reboiler outlet condensate temperature \\
\hline $H_{\text {condensate }}$ & kJ/kg & Calculated (C.11) & Reboiler outlet condensate enthalpy \\
\hline $\dot{m}_{\text {steam }}$ & kg/hr & 8655-FI-2158C & Steam flowrate \\
\hline $\dot{Q}_{\text {reb }}$ & kW & Calculated (C.12) & Reboiler duty \\
\hline SRD & $\mathrm{MJ} / \mathrm{kg} \mathrm{CO}_{2}$ & Calculated (C.13) & Specific reboiler duty \\
\hline $L_{\text {rich }}$ & kg/hr & 8611-FIC-2004 & Rich solvent flowrate into stripper \\
\hline
\end{tabular}

\begin{tabular}{|c|c|c|c|}
\hline$L_{\text {bypass }}$ & $\mathrm{kg} / \mathrm{hr}$ & 8611 -FIC-2260 & \begin{tabular}{c} 
Rich solvent bypass \\
from stripper
\end{tabular} \\
\hline
\end{tabular}

The following table includes values of relevant constants required for the calculations:

\begin{tabular}{|l|l|l|l|}
\hline Name & Value & Unit & Description \\
\hline $R$ & 8.314 & $\mathrm{m}^{3}-\mathrm{kPa}-\mathrm{K}^{-1}-\mathrm{kmol}^{-1}$ & Gas constant \\
\hline $P^{\text {std }}$ & 101.3 & kPa & Standard pressure \\
\hline $T^{\text {std }}$ & 288.15 & K & Standard temperature \\
\hline $M W_{\mathrm{CO}_{2}}$ & 44 & kg/kmol & $\mathrm{CO}_{2}$ molecular weight \\
\hline
\end{tabular}

The equations used are as follows:

$$
\begin{gather*}
H_{2} O_{, F G \text { inlet }}=100 \times \mathrm{pSatW}\left(273.15+T_{g, \text { inlet }}\right) /\left(P_{\text {ambient }}+P_{g, \text { inlet }}\right)  \tag{C.1}\\
C O_{2, F G \text { inlet }}=\left(100-H_{2} O_{, F G \text { inlet }}\right) \frac{C O_{2, F G \text { inlet }- \text { dry basis }}}{100}  \tag{C.2}\\
\dot{m}_{C O_{2}, F G \text { inlet }}=\frac{C O_{2, F G \text { inlet }}}{100} \times G_{\text {in }} \times \frac{P^{\text {std }} M W_{C O_{2}}}{R T^{\text {std }}}  \tag{C.3}\\
H_{2} O_{, F G \text { outlet }}=100 \times \mathrm{pSatW}\left(273.15+T_{g, \text { outlet }}\right) /\left(P_{\text {ambient }}+P_{g, \text { outlet }}\right)  \tag{C.4}\\
C O_{2, F G \text { outlet }}=\left(100-H_{2} O_{, F G \text { outlet }}\right) \frac{C O_{2, F G \text { outlet }- \text { dry basis }}}{100}  \tag{C.5}\\
G_{\text {out }}=G_{\text {in }} \frac{\left(100-H_{2} O_{, F G \text { inlet }}-C O_{2, F G \text { inlet }}\right)}{\left(100-H_{2} O_{, F G \text { outlet }}-C O_{2, F G \text { outlet }}\right)}  \tag{C.6}\\
\dot{m}_{C O_{2}, F G \text { outlet }}=\frac{C O_{2, F G \text { outlet }}}{100} \times G_{\text {out }} \times \frac{P^{\text {std }} M W_{C O_{2}}}{R T^{\text {std }}}  \tag{C.7}\\
C A P=100\left(1-\frac{\dot{m}_{C O_{2}, F G \text { outlet }}}{\dot{m}_{C O_{2}, F G \text { inlet }}}\right)  \tag{C.8}\\
\alpha_{\text {lean }}=3.3181-0.0287 \times T_{\text {lean }- \text { hot }}+0.3607 \times P_{\text {lean }- \text { hot }}  \tag{C.9}\\
H_{\text {steam }}=\text { enthalpySatVapPW }\left(P_{\text {steam }}+P_{\text {ambient }}\right)+\text { cpW }(273.15  \tag{C.10}\\
\left.+T_{\text {steam }}\right) \times\left(273.15+T_{\text {steam }}-\text { tSatW }\left(P_{\text {steam }}+P_{\text {ambient }}\right)\right) \\
H_{\text {condensate }}=\text { enthalpySatLiqPW }\left(P_{\text {condensate }}+P_{\text {ambient }}\right)+\text { cpW }(273.15  \tag{C.11}\\
\left.+T_{\text {condensate }}\right) \times\left(273.15+T_{\text {condensate }}\right. \\
\left.- \text { tSatW }\left(P_{\text {condensate }}+P_{\text {ambient }}\right)\right) \\
\dot{Q}_{\text {reb }}=\frac{\dot{m}_{\text {steam }}}{3600}\left(H_{\text {steam }}-H_{\text {condensate }}\right)  \tag{C.12}\\
S R D=\frac{3600}{1000} \times \frac{\dot{Q}_{\text {reb }}}{C O_{2, F G \text { inlet }}} \times \frac{100}{C A P} \tag{C.13}
\end{gather*}
$$


The following functions, which are incorporated into some of the equations above, are taken from 'Water97_v13.xla', a MS Excel add-in for calculating thermodynamic and transport properties of water and steam using the industrial standard IAPWS-IF97. The details of this package may be found at: http://alexmichinel.com/index.php?p=199

\begin{tabular}{|l|l|l|}
\hline Function Name & Input Variables & Description \\
\hline pSatW & temperature & Calculates vapor pressure of water (bar) \\
\hline tSatW & pressure & Calculates boiling temperature of water (K) \\
\hline cpW & temperature, pressure & Calculates heat capacity of water (kJ/kg/K) \\
\hline enthalpySatVapPW & pressure & Calculates enthalpy of saturated steam (kJ/kg) \\
\hline enthalpySatLiqPW & pressure & Calculates enthalpy of boiling water (kJ/kg) \\
\hline
\end{tabular}

Finally, the values for some key process variables are given in the following table:

\begin{tabular}{|l|l|l|l|l|l|l|l|}
\hline Data No & $L_{\text {rich }}$ & $G_{\text {in }}$ & $\alpha_{\text {lean }}$ & $C O_{2, F G}$ inlet-dry basis & $L_{\text {bypass }}$ & CAP & SRD \\
\hline 1A & 55304 & 31779 & 0.238 & 7.96 & NA & 64.67 & 4.22 \\
\hline 1B & 54201 & 35989 & 0.185 & 7.45 & NA & 74.88 & 4.55 \\
\hline 1C1 & 92106 & 37288 & 0.226 & 7.24 & NA & 96.69 & 3.59 \\
\hline 1C2 & 92103 & 37280 & 0.242 & 8.06 & NA & 86.06 & 3.53 \\
\hline 1D1 & 81396 & 43792 & 0.206 & 7.96 & NA & 76.75 & 3.65 \\
\hline 1D2 & 81402 & 43788 & 0.184 & 7.92 & NA & 85.93 & 3.71 \\
\hline 1E1 & 81301 & 45881 & 0.181 & 7.85 & NA & 83.57 & 3.76 \\
\hline 1E2 & 81298 & 45882 & 0.170 & 7.92 & NA & 87.95 & 3.88 \\
\hline 1F1 & 120801 & 53671 & 0.205 & 7.85 & NA & 91.20 & 3.54 \\
\hline 1F2 & 120805 & 53685 & 0.197 & 7.91 & NA & 93.63 & 3.57 \\
\hline 1G1 & 88896 & 56481 & 0.165 & 7.92 & NA & 80.08 & 4.19 \\
\hline 1G2 & 88903 & 56485 & 0.161 & 7.84 & NA & 82.07 & 4.46 \\
\hline 1H1 & 90299 & 57066 & 0.179 & 8.16 & NA & 71.24 & 3.72 \\
\hline 1H2 & 90300 & 57094 & 0.157 & 7.85 & NA & 82.23 & 4.42 \\
\hline 3A1 & 133900 & 62558 & 0.212 & 7.83 & NA & 83.33 & 3.62 \\
\hline 3A2 & 133897 & 62555 & 0.203 & 7.88 & NA & 87.23 & 3.65 \\
\hline 3B1 & 115398 & 62240 & 0.207 & 8.08 & NA & 73.36 & 3.66 \\
\hline 3B2 & 115402 & 62265 & 0.182 & 8.08 & NA & 82.80 & 3.81 \\
\hline 3C1 & 111900 & 59068 & 0.195 & 8.11 & NA & 79.42 & 3.71 \\
\hline 3C2 & 111900 & 59071 & 0.173 & 8.04 & NA & 90.23 & 3.89 \\
\hline 3D1 & 120200 & 56064 & 0.225 & 8.03 & NA & 78.56 & 3.60 \\
\hline 3D2 & 120200 & 56064 & 0.203 & 8.05 & NA & 85.60 & 3.62 \\
\hline 3E1 & 119497 & 54969 & 0.226 & 8.01 & NA & 79.19 & 3.61 \\
\hline 3E2 & 119501 & 54977 & 0.209 & 8.06 & NA & 84.53 & 3.62 \\
\hline 3F1 & 81501 & 51075 & 0.171 & 8.03 & NA & 78.89 & 4.02 \\
\hline 3F2 & 81500 & 51079 & 0.159 & 7.98 & NA & 82.91 & 4.64 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|l|l|}
\hline 3G1 & 57274 & 42489 & 0.171 & 8.03 & NA & 67.39 & 4.78 \\
\hline 3G2 & 57502 & 42495 & 0.157 & 7.96 & NA & 72.59 & 5.76 \\
\hline 3H1 & 39088 & 30775 & 0.194 & 8.08 & NA & 63.31 & 5.30 \\
\hline 3H2 & 39552 & 30783 & 0.151 & 7.92 & NA & 78.16 & 7.06 \\
\hline 311 & 48302 & 30391 & 0.173 & 9.93 & NA & 67.51 & 5.14 \\
\hline 312 & 48306 & 30382 & 0.157 & 9.96 & NA & 72.39 & 6.37 \\
\hline 3J1 & 85604 & 33781 & 0.230 & 9.96 & NA & 77.69 & 3.64 \\
\hline 3J2 & 85600 & 33788 & 0.205 & 9.95 & NA & 86.27 & 3.63 \\
\hline 3K1 & 103148 & 42993 & 0.219 & 9.97 & NA & 76.50 & 3.56 \\
\hline 3K2 & 103400 & 43012 & 0.194 & 10.01 & NA & 84.30 & 3.56 \\
\hline 2A1 & 107803 & 40784 & 0.192 & 10.21 & NA & 91.46 & 3.57 \\
\hline 2A2 & 107802 & 40800 & 0.184 & 10.05 & NA & 96.06 & 3.62 \\
\hline 3L1 & 96098 & 41276 & 0.190 & 10.02 & NA & 82.38 & 3.67 \\
\hline 3L2 & 96100 & 41281 & 0.171 & 9.98 & NA & 90.68 & 3.85 \\
\hline 3M1 & 94000 & 43481 & 0.174 & 9.96 & NA & 82.63 & 3.98 \\
\hline 3N2 & 119499 & 46480 & 0.190 & 10.02 & NA & 87.37 & 3.70 \\
\hline 301 & 150302 & 48166 & 0.244 & 10.02 & NA & 82.67 & 3.64 \\
\hline 302 & 150303 & 48177 & 0.228 & 10.01 & NA & 86.97 & 3.63 \\
\hline 3P1 & 130202 & 58399 & 0.229 & 7.99 & NA & 78.28 & 3.64 \\
\hline 3P2 & 130204 & 58377 & 0.215 & 7.95 & NA & 83.21 & 3.65 \\
\hline 3Q1 & 99896 & 53382 & 0.179 & 8.02 & NA & 83.44 & 3.73 \\
\hline 3Q2 & 99903 & 53376 & 0.162 & 7.97 & NA & 91.79 & 4.11 \\
\hline 3R1 & 80798 & 51577 & 0.156 & 8.03 & NA & 79.53 & 4.98 \\
\hline 3S1 & 127499 & 50795 & 0.231 & 8.01 & NA & 86.49 & 3.64 \\
\hline 3S2 & 127500 & 50779 & 0.220 & 8.04 & NA & 89.55 & 3.62 \\
\hline 3T1 & 121202 & 49303 & 0.242 & 7.97 & NA & 82.65 & 3.63 \\
\hline 3T2 & 121196 & 49269 & 0.233 & 7.96 & NA & 85.64 & 3.64 \\
\hline 3U1 & 98199 & 47783 & 0.216 & 8.28 & NA & 75.28 & 3.59 \\
\hline 3U2 & 98200 & 47778 & 0.198 & 8.08 & NA & 82.54 & 3.62 \\
\hline 3V1 & 125499 & 46978 & 0.232 & 8.05 & NA & 90.22 & 3.64 \\
\hline 3V2 & 125501 & 46985 & 0.219 & 8.08 & NA & 94.24 & 3.64 \\
\hline 2B & 107101 & 44081 & 0.184 & 8.14 & NA & 97.95 & 3.69 \\
\hline 2C & 107103 & 44082 & 0.162 & 8.06 & NA & 99.05 & 4.44 \\
\hline 2D & 97405 & 48985 & 0.167 & 8.07 & NA & 93.70 & 3.87 \\
\hline 2E & 87699 & 53874 & 0.167 & 7.90 & NA & 78.04 & 3.93 \\
\hline 2F & 87702 & 53875 & 0.157 & 8.00 & NA & 81.96 & 4.42 \\
\hline 2G & 97003 & 44871 & 0.167 & 10.05 & NA & 84.06 & 3.90 \\
\hline 2H & 97003 & 44896 & 0.189 & 10.03 & NA & 74.84 & 3.61 \\
\hline 2 I & 118602 & 36686 & 0.224 & 10.09 & NA & 92.90 & 3.57 \\
\hline 4A & 129998 & 50007 & 0.191 & 9.98 & 25998 & 86.67 & 3.61 \\
\hline 4B & 124999 & 50002 & 0.186 & 10.00 & 25000 & 85.73 & 3.59 \\
\hline 4C & 119981 & 49993 & 0.183 & 9.93 & 23988 & 85.64 & 3.62 \\
\hline 4D & 114987 & 49975 & 0.178 & 9.90 & 22996 & 85.45 & 3.74 \\
\hline 4E & 110035 & 49960 & 0.170 & 10.04 & 22029 & 84.58 & 3.90 \\
\hline 4F & 105009 & 49981 & 0.169 & 9.95 & 21000 & 82.04 & 4.00 \\
\hline 4G(1) & 105018 & 49973 & 0.174 & 10.04 & 15755 & 79.18 & 3.90 \\
\hline
\end{tabular}

\begin{tabular}{|l|l|l|l|l|l|l|l|}
\hline 4G(2) & 105013 & 49968 & 0.168 & 9.74 & 25997 & 84.37 & 4.10 \\
\hline 4H rep & 135000 & 49974 & 0.198 & 10.16 & 25998 & 86.31 & 3.59 \\
\hline 41 & 144985 & 49967 & 0.206 & 10.19 & 25986 & 87.32 & 3.51 \\
\hline 4J & 154994 & 49985 & 0.217 & 10.24 & 25991 & 86.80 & 3.57 \\
\hline 4K & 124996 & 49981 & 0.182 & 10.15 & 19998 & 86.05 & 3.65 \\
\hline 4L & 125003 & 49973 & 0.184 & 9.97 & 15001 & 86.81 & 3.72 \\
\hline 4M & 124990 & 49974 & 0.186 & 9.96 & 9994 & 85.20 & 3.72 \\
\hline 5A & 109983 & 49986 & 0.163 & 9.87 & 25983 & 83.87 & 4.10 \\
\hline 5B & 120018 & 49975 & 0.169 & 9.92 & 26013 & 85.45 & 4.08 \\
\hline 5C & 125000 & 49978 & 0.172 & 9.84 & 26000 & 85.96 & 4.06 \\
\hline 5D & 135079 & 49984 & 0.179 & 9.94 & 26016 & 85.21 & 4.15 \\
\hline 5E & 150004 & 49959 & 0.189 & 9.98 & 26004 & 85.30 & 4.12 \\
\hline 5F & 170005 & 49972 & 0.200 & 10.02 & 26012 & 86.17 & 4.18 \\
\hline 5G & 125009 & 49980 & 0.179 & 10.11 & 20008 & 81.82 & 4.00 \\
\hline 5H & 125001 & 44975 & 0.184 & 10.00 & 26000 & 86.40 & 3.90 \\
\hline 51 & 135000 & 44986 & 0.189 & 9.97 & 26004 & 86.29 & 4.21 \\
\hline 5J & 144995 & 44976 & 0.191 & 9.97 & 25992 & 86.26 & 4.16 \\
\hline 5K & 154982 & 44979 & 0.195 & 9.96 & 25983 & 85.56 & 4.28 \\
\hline 5L & 170026 & 44984 & 0.208 & 9.99 & 26029 & 86.11 & 4.25 \\
\hline 5M & 142788 & 44973 & 0.191 & 9.91 & 19895 & 84.71 & 4.24 \\
\hline 5N & 164402 & 44981 & 0.222 & 10.03 & 10600 & 81.14 & 4.24 \\
\hline 50 & 129990 & 44979 & 0.182 & 9.90 & 25988 & 85.62 & 4.27 \\
\hline 5P & 120010 & 44979 & 0.170 & 10.06 & 26010 & 86.29 & 4.31 \\
\hline 5Q & 129994 & 39996 & 0.202 & 10.11 & 25995 & 86.11 & 4.17 \\
\hline 5R & 140029 & 39985 & 0.205 & 10.14 & 26031 & 86.53 & 4.30 \\
\hline 5S & 149992 & 39980 & 0.213 & 9.98 & 25991 & 86.47 & 4.35 \\
\hline
\end{tabular}

\section*{References}
1. J.C. Morgan, D. Bhattacharyya, C. Tong, D.C. Miller. Uncertainty quantification of property models: methodology and its applications to $\mathrm{CO}_{2}$-loaded aqueous MEA solutions. AIChE Journal. 2015, Vol. 61 (6), pp. 1822-1839.
2. J.C. Morgan, A.S. Chinen, B. Omell, D. Bhattacharyya, C. Tong, D.C. Miller. Thermodynamic modeling and uncertainty quantification of $\mathrm{CO}_{2}$-loaded aqueous MEA solutions. Chemical Engineering Science. 2017, Vol. 168, pp. 309-324.
3. A.S. Chinen, J.C. Morgan, B. Omell, D. Bhattacharyya, C. Tong, D.C. Miller. Development of a rigorous modeling framework for solvent-based $\mathrm{CO}_{2}$ capture. Part 1. Hydraulic and mass transfer models and their uncertainty quantification. Industrial \& Engineering Chemistry Research. 2018, Vol. 57, pp. 10448-10463.
4. J.C. Morgan, A.S. Chinen, B. Omell, D. Bhattacharyya, C. Tong, D.C. Miller. Development of a rigorous modeling framework for solvent-based $\mathrm{CO}_{2}$ capture. Part 2. Steady-state validation and uncertainty quantification with pilot plant data. Industrial \& Engineering Chemistry Research. 2018, Vol. 57, pp. 10464-10481.
5. K. Chaloner, I. Verdinelli. Bayesian experimental design: a review. Statistical Science. 1995, Vol. 10(3), pp. 273-304.
6. W.K. Wong. Comparing robust properties of A, D, E, and G-optimal designs. Computational Statistics \& Data Analysis. 1994, Vol. 18, pp. 441-448.
7. Steady State and Dynamic Monoethanolamine (MEA) Test Runs Conducted by CCSI ${ }^{2}$ at the National Carbon Capture Center. https://static1.squarespace.com/static/566b0ac3df40f3a731712cf4/t/5af445630e2e728fc7de ba9a/1525957989997/NCCC_Test_Run_June_July_2017_CCSI2_Report_R2.pdf
8. F.B. Soepyan, C.M. Anderson-Cook, D. Bhattacharyya, J.C. Morgan, B.P. Omell, M.A. Zamarripa, J.C. Eslick, M.S. Matuszewski, D.C. Miller, J.R. Gattiker, C.S. Russell, J.D. Kress, K.S. Bhat, C.H. Tong, B. Ng, J.C. Ou. Sequential design of experiments to maximize learning from carbon capture pilot scale testing. Proceedings of the $13^{\text {th }}$ International Symposium on Process Systems Engineering. 2018, pp. 283-288.
9. J.H. Friedman. Multivariate adaptive regression splines. The Annals of Statistics. 1991, Vol. 19(1), pp. 1-141.
10. E. Gjernes, S. Pedersen, T. Cents, G. Watson, B.F. Fostås, M.I. Shah, G. Lombardo, C. Desvignes, N.E. Flø, A.K. Morken, T. de Cazenove, L. Faramarzi, E.S. Hamborg. Results from $30 \mathrm{wt} \%$ MEA performance testing at the $\mathrm{CO}_{2}$ Technology Centre Mongstad. Energy Procedia. 2017, Vol. 114, pp. 1146-1157.