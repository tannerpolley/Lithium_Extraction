\title{
Thermodynamic Modeling and Uncertainty Quantification of $\mathbf{C O}_{\mathbf{2}}$-Loaded Aqueous MEA Solutions
}

\author{
Joshua C. Morgan ${ }^{\mathrm{a}}$, Anderson Soares Chinen ${ }^{\mathrm{a}}$, Benjamin Omell ${ }^{\mathrm{b}}$, Debangsu Bhattacharyya ${ }^{\mathrm{a}, *}$, Charles Tong ${ }^{\mathrm{c}}$, David C. Miller ${ }^{\mathrm{b}}$ \\ ${ }^{\mathrm{a}}$ Department of Chemical and Biomedical Engineering, West Virginia University, Morgantown, WV 26506, USA
}
${ }^{\mathrm{b}}$ National Energy Technology Laboratory, 626 Cochrans Mill Rd, Pittsburgh, PA 15236, USA
${ }^{\mathrm{c}}$ Lawrence Livermore National Laboratory, Livermore, CA 94550, USA

\begin{abstract}
The accurate characterization of the thermodynamic models of a reactive solvent-based $\mathrm{CO}_{2}$ capture system is essential for adequately capturing system behavior in a process model. Moreover, uncertainty in these models can significantly affect simulation results, although it is often neglected. With this incentive, a model of thermodynamic properties, including vaporliquid equilibrium (VLE), enthalpy, and solution chemistry, has been developed using a rigorous methodology for the aqueous monoethanolamine (MEA) system as a baseline. The final thermodynamic framework consists of both a deterministic and stochastic model. The deterministic model is developed by regressing parameters of the e-NRTL activity coefficient model in Aspen Plus ${ }^{\circledR}$ to VLE, heat capacity, and heat of absorption data while downselecting the model's large parameter space through use of information-theoretic criteria. The stochastic model is developed through an uncertainty quantification (UQ) procedure, using the results of the deterministic regression to determine a prior parameter distribution. This prior distribution and the experimental VLE data are used to derive a posterior distribution through Bayesian inference, which is used to represent the final stochastic model. A reaction model in which the kinetics are written in terms of the reaction equilibrium constants, to ensure consistency with the thermodynamics model, is developed. These new thermodynamic and reaction models are incorporated into an existing MEA system process model from the open literature, and the prior and posterior parameter distributions are propagated through the models. This provides valuable insight into the extent to which uncertainty in thermodynamic models affects key process variables, including $\mathrm{CO}_{2}$ capture efficiency and energy requirement for solvent regeneration.
\end{abstract}

Keywords: uncertainty quantification, thermodynamics, MEA, CO2 capture
*Corresponding author. Tel:+1-3042939335, Fax: +1-3042934139
E-mail address: Debangsu.Bhattacharyya@mail.wvu.edu

\section*{List of Figure Captions}
Figure 1: Overview of UQ for Physical Property Models ..... 16
Figure 2. Comparison of $\mathrm{CO}_{2}$ partial pressure data from various sources for solutions of $30 \mathrm{wt} \%$ MEA and temperatures of (A) $40^{\circ} \mathrm{C}$, (B) $80^{\circ} \mathrm{C}$, and (C) $120^{\circ} \mathrm{C}$ as a function of $\mathrm{CO}_{2}$ loading to new and existing models. ..... 24
Figure 3. Comparison of phase envelope predictions to experimental data. T-xy data from Cai et al. (1996) are shown for fixed pressure of (A) 101.33 kPa and (B) 66.66 kPa . P-xy data from Tochigi et al. (1999) are shown at fixed temperature of (C) 363.15 K ..... 26
Figure 4. Heat of absorption data (Kim et al., 2014) for solutions of $30 \mathrm{wt} \%$ MEA and temperatures of $40^{\circ} \mathrm{C}, 80^{\circ} \mathrm{C}$, and $120^{\circ} \mathrm{C}$ as a function of $\mathrm{CO}_{2}$ loading compared to model predictions for (A) CCSI, (B) Plaza, and (C) Aspen Plus library models. ..... 28
Figure 5. CCSI model and Plaza model predictions of heat capacity compared to data (Weiland et al., 1997) for solutions at $25^{\circ} \mathrm{C}$ for various values of MEA weight percent as a function of $\mathrm{CO}_{2}$ loading ..... 30
Figure 6: $\mathrm{CO}_{2}$ partial pressure prediction for stochastic model with a modified prior parameter distribution with experimental data for $30 \mathrm{wt} \%$ MEA at temperatures of (a) $40^{\circ} \mathrm{C}$, (b) $80^{\circ} \mathrm{C}$, and (c) $120^{\circ} \mathrm{C}$ ..... 34
Figure 7: Quality of response surface model for $\mathrm{CO}_{2}$ partial pressure. (A) Parity plot for cross validation (10-fold) of response surface model in comparison to simulation values. Values shown correspond to $\ln (P C O 2[k P a])$. (B) Ratio of response surface predictions to simulation values for $\mathrm{CO}_{2}$ partial pressure (without logarithmic transformation) as a function of $\mathrm{CO}_{2}$ loading. ..... 36
Figure 8: Single parameter marginal probability density functions for prior and posterior distributions. Red and blue lines represent prior and posterior distributions, respectively, and parameter numbers match those given in Table 4. Parameter values are normalized by dividing by the deterministic value of the respective parameter ..... 38
Figure 9: Normalized prior and posterior two-parameter marginal distributions for (A) parameters 1 and 2 and (B) parameters 5 and 6 . ..... 39
Figure 10: $\mathrm{CO}_{2}$ partial pressure prediction for stochastic model with a posterior parameter distribution with experimental data for $30 \mathrm{wt} \%$ MEA at temperatures of (a) $40^{\circ} \mathrm{C}$, (b) $80^{\circ} \mathrm{C}$, and (c) $120^{\circ} \mathrm{C}$ ..... 41
Figure 11: Pdfs for $\mathrm{CO}_{2}$ capture percentage for stochastic absorber models for (A) Case 1 and (B) Case 2 ..... 43
Figure 12: Pdfs for predicted lean solvent loading for stochastic regenerator models for (A) Case 1 and (B) Case 2 ..... 45

\section*{1. Introduction}

Due to increasing apprehension regarding the role of fossil fuel emissions on global climate change, the development and deployment of more efficient post-combustion $\mathrm{CO}_{2}$ capture technologies is of great concern to the energy generation industry. The U.S. Department of Energy's Carbon Capture Simulation Initiative (CCSI) is focused on developing computational tools and models to accelerate the development and commercialization of $\mathrm{CO}_{2}$ capture technologies (Miller et al., 2014). A specific interest of CCSI is the development of highly accurate thermodynamic models with quantified uncertainty for chemical solvents. The standard baseline solvent for developing a framework for modeling with uncertainty quantification (UQ) is the monoethanolamine (MEA) system, considering that aqueous solutions with $30 \mathrm{wt} \%$ MEA have been the industrial standard for acid gas removal since 1970 and significant data on such systems is readily available (Amundsen et al., 2009). Alkanolamines such as MEA are extensively used in $\mathrm{CO}_{2}$ capture applications due to their chemical structure, which includes hydroxyl groups that increase water solubility and an amino group that provides the alkalinity necessary to capture $\mathrm{CO}_{2}$ (Jayarathna et al., 2013). MEA also has a relatively fast reaction rate with $\mathrm{CO}_{2}$, which is essential for keeping the liquid phase concentration of molecular $\mathrm{CO}_{2}$ low and the driving force for absorption high. A major drawback for this solvent, however, is the large energy input required for solvent regeneration (Yu et al., 2013). A modeling framework which enables uncertainty quantification (UQ) is essential to evaluate and develop systems utilizing novel solvents for $\mathrm{CO}_{2}$ capture as alternatives to the traditional MEA system. Of particular importance is the development of models that can be truly predictive to help accelerate process scale up. In this work, such a modeling framework is developed and applied to the aqueous MEA system to demonstrate its capabilities.

Thermodynamic models need to be accurate and consistent for evaluating the performance of the absorber and stripper columns in solvent-based $\mathrm{CO}_{2}$ capture processes. In the absorber, the vapor-liquid equilibrium (VLE) is strongly affected by the increase in temperature due to the exothermic nature of the chemical absorption. Stripper reboiler duty is an important factor for the economic viability of a solvent-based $\mathrm{CO}_{2}$ capture process (Yu et al., 2013) and its accurate assessment is necessary and contingent upon the accuracy of the enthalpy model. For a nonideal
system, the VLE model is dependent on the enthalpy model because the excess enthalpy (and therefore excess Gibbs free energy) is thermodynamically related to activity coefficients. In addition, the chemistry of the $\mathrm{CO}_{2}$-loaded solution affects both VLE and enthalpy models. Therefore, the thermodynamic framework needs to consider the VLE model, enthalpy model and the chemistry model together. Furthermore, the operating conditions along the absorbers and strippers vary widely in terms of temperature, solvent concentration, loading, and partial pressure of $\mathrm{CO}_{2}$. Therefore, the thermodynamic framework needs to be accurate over the entire expected operating range of interest.

The existing literature is rich in deterministic thermodynamic models of the MEA system. Frameworks using the e-NRTL and UNIQUAC models are available in the literature (Hilliard, 2008; Plaza, 2012; Zhang et al., 2011; Aspen Plus documentation, 2013a; Aronu et al., 2011; Kaewsichan et al., 2001; Vrachnos et al., 2006). Examples of two thermodynamic models that use the e-NRTL activity coefficient model are the model available as part of the Aspen Plus example library for the MEA system (Aspen Plus documentation, 2013a) and the Phoenix model developed by Plaza (2012). Both models have been validated with an extensive set of thermodynamic data that span the temperature and composition ranges applicable to absorber and regenerator columns in a solvent-based $\mathrm{CO}_{2}$ capture process. Accordingly, these two models will be referred to throughout this work as a basis of comparison for the new model developed herein. The Aspen Plus library model has been developed considering binary and ternary VLE, heat capacity, and heat of absorption data. The Plaza model, however, does not include heat of absorption data or binary system VLE data in its regression. The major aspect missing from the deterministic models available in the literature, including the Aspen Plus library model and the Plaza model, is a rigorous approach to parameter selection, which is essential for highly parameterized models such as e-NRTL. Moreover, as noted in the work of Mathias and Gilmartin (2014), typical power law kinetic models do not correctly capture the complex temperature dependence of chemical equilibrium constants for electrolyte systems. This issue can be fixed by representing equilibrium reaction kinetics in terms of a forward rate and a chemical equilibrium constant rather than including separate rate constants for the forward and reverse reactions, which may result in inconsistency with the thermodynamic model. This approach, however, is not generally used in the existing literature.

In addition, to the best of our knowledge, there is no work in the existing literature applying UQ to the thermodynamic framework of the MEA- $\mathrm{CO}_{2}-\mathrm{H}_{2} \mathrm{O}$ system. UQ can be performed in a framework incorporating uncertainties in model form, parameter values, and experimental data (Whiting, 1996). In the existing literature, a systematic approach to UQ of not only the thermodynamic framework, but physical property models in general, and other chemical engineering applications is minimal. The work of Whiting (1996) provides an overview of UQ and simple examples of strategies for quantification of thermodynamic model uncertainties involving Monte Carlo simulation, regression analysis, and optimization. A Monte Carlo approach has been applied to study the sources of uncertainty in reaction kinetics of a coal devolatilization process (Gel et al., 2014). Multiple studies on UQ of multiphase CFD models of fluidized beds have been performed (Gel et al., 2013; Lane et al., 2014). A rigorous approach to UQ of the thermodynamics of a solid sorbent-based $\mathrm{CO}_{2}$ capture process has been developed (Mebane et al., 2013). Perturbation methods have been used to study the effects of such factors as chemical equilibrium, reaction kinetics, activity coefficient models and viscosity on process simulations, including $\mathrm{CO}_{2}$ capture applications (Mathis and Gilmartin, 2014; Mathias, 2014). Weber et al. (2006) use a Bayesian approach to study thermodynamic uncertainty on the chemical speciation in river water. Mišković and Hatzimanikatis (2011) have developed a methodology in which the uncertainty in enzyme kinetics is modeled and the responses of metabolic reactions to changes in enzyme activities under uncertainty are predicted. A study by Sarkar et al. (2012) involves Bayesian calibration of thermodynamic parameters for geochemical speciation.

In our previous work (Morgan et al., 2015), a rigorous methodology was proposed for developing stochastic physical property models. In that methodology, a given physical property is represented as a function of temperature and composition by a correlation, and the correlation parameters are fit to experimental data. A Bayesian inference procedure for UQ is performed with a subset of the model parameters, which is selected by a sensitivity study. The confidence intervals of the parameters determined by the regression are used to determine their prior distributions, and the posterior distributions are derived from Bayesian inference and used in the final stochastic model. However, the previous work included properties models such as density, surface tension and viscosity models that could be represented by very few equations and contained few parameters for UQ. As noted before, the VLE, enthalpy and chemistry models
need to be considered together while developing the thermodynamic framework. This leads to a large number of complex equations with a significantly larger parameter space than considered earlier. The inclusion of UQ into complex models can be made difficult by the lack of data for accurate calibration of the model parameters (Papadimitriou, 2014). Therefore, a methodology has been developed for handling these issues.

In summary, the contributions of the current work are as follows:
- Parameters for the VLE, enthalpy, and chemistry models are regressed together using data for binary (MEA- $\mathrm{H}_{2} \mathrm{O}$ ) and ternary (MEA- $\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ ) VLE, heat of absorption, and heat capacity.
- The data included in the regression are obtained from nearly all available sources in the literature that the authors are aware of corresponding to temperature, pressure, and composition values that span the ranges of interest for the industrial CO2 capture process.
- The reaction kinetics of the system have been written in a form that ensures consistency with the thermodynamic model through inclusion of the chemical equilibrium constant.
- A parameter screening methodology based on information-theoretic criteria has been employed to determine an optimal set of parameters for inclusion in the final model.
- An approach for UQ of the thermodynamic framework is developed and employed for developing a stochastic model of the system.

Finally, a case study is performed in which the parametric uncertainty in the thermodynamic framework is propagated through a process model consisting of an absorber and stripper in order to quantify the effect of this uncertainty in the performance of the MEA-based CO2 capture process.

\section*{2. Model Development and General Methodology}

\subsection*{2.1 Thermodynamic Model}

The thermodynamic model equations described here are based on those implemented in the thermodynamic framework of Aspen Plus ${ }^{\circledR}$ (Aspen Plus documentation, 2013b). The condition for vapor-liquid equilibrium for a mixture is as follows; for each component $i$ in equilibrium,

$$
\begin{equation*}
\hat{f}_{i}^{V}=\hat{f}_{i}^{L} \tag{1}
\end{equation*}
$$

where $\hat{f}_{i}^{V}$ and $\hat{f}_{i}^{L}$ are the vapor and liquid phase component fugacities. Considering an activity coefficient model is used for the liquid phase nonidealities, Eq. 1 can be written as:

$$
\begin{equation*}
\hat{\varphi}_{i} y_{i} P=\gamma_{i} x_{i} f_{i}^{o} \tag{2}
\end{equation*}
$$

where $x_{i}$ and $y_{i}$ are the liquid and vapor phase mole fractions, $P$ is the system pressure, $\hat{\varphi}_{i}$ is the vapor phase fugacity coefficient, $\gamma_{i}$ is the symmetric activity coefficient, and $f_{i}^{O}$ is the liquid phase reference fugacity. For solvents, the liquid phase reference fugacity is calculated as:

$$
\begin{equation*}
f_{i}^{o}=\varphi_{i}^{s a t} P_{i}^{s a t} \exp \left(\frac{1}{R T} \int_{P_{i}^{s a t}}^{P} V_{i}^{L} d P\right) \tag{3}
\end{equation*}
$$

where $P_{i}^{s a t}$ and $V_{i}^{L}$ are the vapor pressure and molar volume of species $i$, and $\varphi_{i}^{s a t}$ is the pure component fugacity coefficient evaluated at the system temperature and vapor pressure. For components to which Henry's law is applied, the liquid phase reference fugacity is calculated as:

$$
\begin{equation*}
f_{i}^{o}=\frac{k_{H i}}{\lim _{x_{i} \rightarrow 0} \gamma_{i}}=\frac{k_{H i}}{\gamma_{i}^{\infty}} \tag{4}
\end{equation*}
$$

where $k_{H i}$ is the Henry's constant, which is a function of temperature. The symmetric activity coefficient of species $i$ is calculated as:

$$
\begin{equation*}
\ln \left(\gamma_{i}\right)=\left.\frac{1}{R T} \frac{\partial\left(n G^{e x}\right)}{\partial n_{i}}\right|_{T, P, n_{j \neq i}} \tag{5}
\end{equation*}
$$

where $n$ and $n_{i}$ are the total number of moles and the number of moles of component $i$ and $G^{e x}$ is the excess Gibbs free energy of solution. The infinite dilution activity coefficient ( $\gamma_{i}^{\infty}$ ) is defined in the denominator of Eq. 4, and the asymmetric activity coefficient is defined as:

$$
\begin{equation*}
\gamma_{i}^{*}=\frac{\gamma_{i}}{\gamma_{i}^{\infty}} \tag{6}
\end{equation*}
$$


Furthermore, the excess enthalpy ( $H^{e x}$ ) is related to the activity coefficient by:

$$
\begin{equation*}
H^{e x}=-\left.R T^{2} \sum_{i} x_{i}\left(\frac{\partial \ln \gamma_{i}}{\partial T}\right)\right|_{P, x} \tag{7}
\end{equation*}
$$


The heat capacity of a liquid mixture ( $C_{p, m}{ }^{l}$ ), can be calculated as the temperature derivative of the liquid mixture enthalpy ( $H_{m}{ }^{l}$ ), given the relationship:

$$
\begin{equation*}
H_{m}{ }^{l}(T+\Delta T)-H_{m}{ }^{l}(T)=\int_{T}^{T+\Delta T} C_{p, m}{ }^{l} d T \tag{8}
\end{equation*}
$$


Heat of absorption can be calculated by an energy balance on a mixing process:

$$
\begin{equation*}
\Delta H_{a b s}=\frac{m_{\text {final }} H_{\text {final }}-m_{\text {initial }} H_{\text {initial }}-m_{\mathrm{CO}_{2}} H_{\mathrm{CO}_{2}}}{n_{\mathrm{CO}_{2}}} \tag{9}
\end{equation*}
$$

where $m_{\text {initial }}$ and $m_{\text {final }}$ are the initial and final mass units of solvent to which $m_{\mathrm{CO}_{2}}$ mass units ( $n_{\mathrm{CO}_{2}}$ molar units) of $\mathrm{CO}_{2}$ are added, and the mass enthalpy terms are defined analogously. Eq. 9 is valid for two distinct definitions of heat of absorption, the differential and integral heat of absorption (Zhang et al., 2011). The differential heat of absorption refers to the heat effect associated with adding an incremental amount of $\mathrm{CO}_{2}$ to a solution of specific $\mathrm{CO}_{2}$ loading. In contrast, the integral heat of absorption is the heat effect due to adding the total amount of $\mathrm{CO}_{2}$ to an unloaded solution required to increase the solution loading to a specific value. For a nonideal system, the excess enthalpy term is essential in the enthalpy model on which the heat capacity and heat of absorption are dependent. Moreover, for a reactive system, the reaction equilibrium constant ( $K_{e q}$ ) is related to the Gibbs free energy of reaction ( $\Delta G_{r x n}$ ) by:

$$
\begin{equation*}
\Delta G_{r x n}=-R T \ln K_{e q} \tag{10}
\end{equation*}
$$

where $\Delta G_{r x n}$ is also dependent on the excess Gibbs energy for a non-ideal system. Since the VLE, heat capacity, heat absorption, and reaction equilibrium for this system are all related to the activity coefficient model, it is clear that a consistent thermodynamic framework that incorporates all of these properties is required.

In this work, the thermodynamic framework of the MEA- $\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ system is modeled by the ELECNRTL property method in Aspen Plus ${ }^{\circledR}$ (Aspen Plus documentation, 2013b), which uses the Redlich-Kwong equation of state to calculate the vapor phase fugacity coefficients and the electrolyte Non-Random Two-Liquid (e-NRTL) model (Chen et al., 1982) to calculate the excess Gibbs free energy. For the e-NRTL model, the excess Gibbs energy is given as a sum of three components:

$$
\begin{equation*}
G^{e x}=G_{P D H}^{e x}+G_{B o r n}^{e x}+G_{L C}^{e x} \tag{11}
\end{equation*}
$$


The first two terms, the Pitzer-Debye-Hückel model and the Born equation are used to represent the contribution of the long range ion-ion interactions. The third term, which the model parameters that may be adjusted to fit experimental data, represents the contribution of local interactions. This term is given by:

$$
\begin{gather*}
G_{L C}^{e x}=\sum_{m} X_{m} \frac{\sum_{j} X_{j} G_{j m} \tau_{j m}}{\sum_{k} X_{k} G_{k m}}+\sum_{c} X_{c} \sum_{a^{\prime}}\left(\frac{X_{a^{\prime}}}{\sum_{a^{\prime \prime}} X_{a^{\prime \prime}}}\right) \frac{\sum_{j} X_{j} G_{j c, a^{\prime} c} \tau_{j c, a^{\prime} c}}{\sum_{k} X_{k} G_{k c, a^{\prime} c}}  \tag{12}\\
+\sum_{a} X_{a} \sum_{c^{\prime}}\left(\frac{X_{c^{\prime}}}{\sum_{c^{\prime \prime}} X_{c^{\prime \prime}}}\right) \frac{\sum_{j} X_{j} G_{j a, c^{\prime} a} \tau_{j a, c^{\prime} a}}{\sum_{k} X_{k} G_{k a, c^{\prime} a}}
\end{gather*}
$$


Here, molecules are represented by the subscript $m$, cations by $c, c^{\prime}$ and $c^{\prime \prime}$, and anions by $a$, a and $a^{\prime \prime}$. The subscripts $j$ and $k$ represent any species. The terms $G$ are defined by the convention:

$$
\begin{gather*}
G_{i m}=\exp \left(-\alpha_{i m} \tau_{i m}\right)  \tag{13}\\
G_{c a, m}=\exp \left(-\alpha_{c a, m} \tau_{c a, m}\right) \tag{14}
\end{gather*}
$$

with other interaction terms defined analogously. The terms $X$ are defined by:

$$
\begin{equation*}
X_{j}=x_{j} L_{j} \tag{15}
\end{equation*}
$$

where $x_{j}$ is the liquid phase mole fraction and $L_{j}$ is unity for molecular species and the charge number for ionic species. The terms $\alpha$ and $\tau$ are nonrandomness factors and energy parameters, respectively. Molecule-molecule binary parameters and electrolyte-molecule pair parameters are defined, respectively, as:

$$
\begin{gather*}
\tau_{m m^{\prime}}=A_{m m^{\prime}}+\frac{B_{m m^{\prime}}}{T}+E_{m m^{\prime}} \ln (T)+F_{m m^{\prime}} T  \tag{16}\\
\tau_{c a, m}=C_{c a, m}+\frac{D_{c a, m}}{T}+E_{c a, m}\left(\frac{T^{r e f}-T}{T}+\ln \left(\frac{T}{T^{r e f}}\right)\right) \tag{17}
\end{gather*}
$$


Molecule-electrolyte and electrolyte-electrolyte pair parameters are defined analogously to the electrolyte-molecule pair parameters. In Eq. 17, the reference temperature 298.15 K and all terms aside from temperature are fitting parameters.

In this model, the liquid enthalpy of a mixture is calculated by:

$$
\begin{equation*}
H_{m}^{l}(T)=\sum_{i} x_{i} H_{i}+\sum_{k} x_{k} H_{k}^{\infty}+H^{e x} \tag{18}
\end{equation*}
$$

where $i$ denotes molecular species and $k$ denotes electrolyte species. The enthalpy of solvents is defined as:

$$
\begin{equation*}
H_{i}(T)=\Delta H_{f}^{i g}\left(T^{r e f}\right)+\int_{T^{r e f}}^{T} C_{p, i}^{i g} d T+\Delta H_{i}^{d e p}(T, p)-\Delta H_{i}^{v a p}(T) \tag{19}
\end{equation*}
$$

and the enthalpy of molecular solutes, or Henry's components, is:

$$
\begin{equation*}
H_{i}(T)=H_{i}^{i g}(T)-R T^{2}\left(\frac{\partial \ln k_{H i}}{\partial T}\right) \tag{20}
\end{equation*}
$$


The enthalpy of the ionic species is:

$$
\begin{equation*}
H_{k}^{\infty}(T)=\Delta H_{f, k}^{\infty}\left(T^{r e f}\right)+\int_{T^{r e f}}^{T} C_{p, k}^{\infty} d T \tag{21}
\end{equation*}
$$


Adjustable parameters in these equations include the ideal gas enthalpy of formation of molecular species ( $\Delta H_{f}^{i g}\left(T^{r e f}\right)$ ) at reference temperature 298.15 K and the aqueous infinite dilution heat of formation of ionic species ( $\Delta H_{f, k}^{\infty}\left(T^{\text {ref }}\right)$ ). In Eq. 19, the term $\Delta H_{i}^{\text {dep }}(T, p)$ is the vapor enthalpy of departure of solvent and $\Delta H_{i}^{\text {vap }}(T)$ is the heat of vaporization of solvent. In Eq. 20, $k_{H i}$ is the Henry's constant, defined, for a mixed solvent, as:

$$
\begin{gather*}
\ln \left(\frac{k_{H i}}{\gamma_{i}^{\infty}}\right)=\sum_{A} \frac{x_{A}\left(V_{c A}\right)^{2 / 3}}{\sum_{B} x_{B}\left(V_{c B}\right)^{2 / 3}} \ln \left(k_{H i A} / \gamma_{i A}^{\infty}\right)  \tag{22}\\
k_{H i A}(T, P)=k_{H i A}\left(T, P_{A}^{*}\right) \exp \left(\frac{1}{R T} \int_{P_{A}^{s a t}}^{P} V_{i A}^{\infty} d p\right)  \tag{23}\\
\ln \left\{k_{H i A}\left(T, P_{A}^{s a t}\right)\right\}=a_{i A}+\frac{b_{i A}}{T}+c_{i A} \ln (T)+d_{i A} T+\frac{e_{i A}}{T^{2}} \tag{24}
\end{gather*}
$$


In Eq. 23, $k_{H i}$ and $k_{H i A}$ refer to the Henry's constant in the mixture and in pure solvent $A$, respectively, and infinite dilution activity coefficients $\gamma_{i}^{\infty}$ and $\gamma_{i A}^{\infty}$ are defined analogously. The mole fraction and critical volume of $A$ (or $B$ ) are $x_{A}\left(x_{B}\right)$ and $V_{c A}\left(V_{c B}\right)$. In Eq. 23, $V_{i A}^{\infty}$ is the partial molar volume of species $i$ at infinite dilution in pure solvent $A$, as calculated by the Brelvi-O'Connell model (Aspen Plus documentation, 2013c). The correlation in Eq. 24 includes the adjustable parameters in the Henry's constant model ( $a_{i A}, b_{i A}$, etc.) for a binary species pair. Additional adjustable parameters are included in the ideal gas ( $C_{p, i}^{i g}$ ) and aqueous infinite dilution ( $C_{p, k}^{\infty}$ ) heat capacity equations, which are given by:

$$
\begin{gather*}
C_{p, i}^{i g}=C_{1 i}+C_{2 i} T+C_{3 i} T^{2}+C_{4 i} T^{3}+C_{5 i} T^{4}+C_{6 i} T^{5}  \tag{25}\\
C_{p, k}^{\infty}=C_{1 k}+C_{2 k} T+C_{3 k} T^{2}+\frac{C_{4 k}}{T}+\frac{C_{5 k}}{T^{2}}+\frac{C_{6 k}}{\sqrt{T}} \tag{26}
\end{gather*}
$$


\subsection*{2.2 Reaction Kinetics Model}

For this work, the MEA- $\mathrm{CO}_{2}-\mathrm{H}_{2} \mathrm{O}$ system is modeled as a reactive system with the following equilibrium reactions, given in the work of Hilliard (2008):

$$
\begin{align*}
& 2 \mathrm{MEA}+\mathrm{CO}_{2} \leftrightarrow \mathrm{MEA}^{+}+\mathrm{MEACOO}^{-}  \tag{27}\\
& \mathrm{MEA}+\mathrm{CO}_{2}+\mathrm{H}_{2} \mathrm{O} \leftrightarrow \mathrm{MEA}^{+}+\mathrm{HCO}_{3}^{-} \tag{28}
\end{align*}
$$


Although other ionic species (e.g. $\mathrm{H}^{+}, \mathrm{OH}^{-}$, and $\mathrm{CO}_{3}^{2-}$ ) appear in solution, their concentrations are shown to be negligible at the process conditions of interest. These two reactions are also assumed to fully represent the chemistry of the $\mathrm{CO}_{2}$-loaded aqueous MEA system in the work of Han et al. (2011), in which molecular dynamics is employed to study the mechanisms of these reactions. As discussed earlier, typical power law kinetics often used in the literature do not correctly capture the complex temperature dependence of chemical equilibrium for the electrolyte systems. Therefore, the reaction kinetics are modified to the form given in Eqs. 29 and 30, which is similar to that of the work of Mathias and Gilmartin (2014) for an AMP-CO2$\mathrm{H}_{2} \mathrm{O}$ system.

$$
\begin{align*}
& r_{1}=A_{1}^{f} \exp \left(-\frac{E_{1}^{f}}{R}\left(\frac{1}{T}-\frac{1}{298.15}\right)\right) a_{M E A}^{2} a_{C O_{2}}\left(1-\frac{a_{M E A^{+}} a_{M E A C O O^{-}}}{K_{1} a_{M E A}^{2} a_{C O_{2}}}\right)  \tag{29}\\
& r_{2}=A_{2}^{f} \exp \left(-\frac{E_{2}^{f}}{R}\left(\frac{1}{T}-\frac{1}{298.15}\right)\right) a_{M E A} a_{C O_{2}}\left(1-\frac{a_{M E A^{+}} a_{H C O_{3}^{-}}}{K_{2} a_{M E A} a_{C O_{2}} a_{H_{2} O}}\right) \tag{30}
\end{align*}
$$

where $K_{1}$ and $K_{2}$ are the equilibrium constants given by:

$$
\begin{gather*}
K_{1}=\left.\frac{\gamma_{M E A}+x_{M E A}+\gamma_{M E A C O O^{-}} x_{M E A C O O^{-}}}{\left(\gamma_{M E A}^{*} x_{M E A}\right)^{2} \gamma_{C O_{2}}^{*} x_{C O_{2}}}\right|_{e q}  \tag{31}\\
K_{2}=\left.\frac{\gamma_{M E A}+x_{M E A}+\gamma_{H C O_{3}^{-}} x_{H C O_{3}^{-}}}{\gamma_{M E A}^{*} x_{M E A} \gamma_{C O_{2}}^{*} x_{C O_{2}} \gamma_{H_{2} O} x_{H_{2} O}}\right|_{e q} \tag{32}
\end{gather*}
$$

where $x_{i}$ denotes the liquid phase mole fraction of a given species and $\gamma_{i}$ and $\gamma_{i}^{*}$ represent symmetrical and unsymmetrical activity coefficients, noting that unsymmetrical activity coefficients are used for $\mathrm{CO}_{2}$ and MEA, which are modeled as Henry's coefficients in this work. In this work, the pre-exponential factor and activation energy for the forward reactions are taken from the work of Plaza (2012), and shown in Table 1. Since this reaction kinetics model is not in one of the standard forms used in Aspen Plus ${ }^{\circledR}$, it is incorporated into the simulation through a FORTRAN user model.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 1. Reaction kinetics parameters}
\begin{tabular}{|l|l|}
\hline \multicolumn{2}{|l|}{Pre-Exponential Factor ( $\mathrm{kmol} / \mathrm{m}^{3}$-s)} \\
\hline $A_{1}^{f}$ & $8.56 \times 10^{10}$ \\
\hline $A_{2}^{f}$ & $2.30 \times 10^{4}$ \\
\hline \multicolumn{2}{|c|}{Activation Energy (J/mol)} \\
\hline $E_{1}^{f}$ & $3.96 \times 10^{3}$ \\
\hline $E_{2}^{f}$ & $4.90 \times 10^{4}$ \\
\hline
\end{tabular}
\end{table}

\subsection*{2.3 Deterministic Modeling Methodology}

The Aspen Plus ${ }^{\circledR}$ data regression system is used to calibrate the parameter values to fit the experimental VLE data for the binary MEA- $\mathrm{H}_{2} \mathrm{O}$ system, the ternary MEA- $\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ system, differential heat of absorption, and heat capacity data for the ternary system. Since heat of absorption is not directly incorporated into Aspen Plus ${ }^{\circledR}$ as a physical property that can be included in the data regression, it has been included through a FORTRAN user model, in which it is calculated as in Eq. 9. The objective function to be minimized is the sum of squared error weighed by the reciprocal of the variance of the measurements.

A separate regression is performed to calibrate values for the heat capacity polynomials, including the ideal gas heat capacity of MEA (Eq. 25) and the aqueous infinite dilution heat capacity of $\mathrm{MEA}^{+}$and $\mathrm{MEACOO}^{-}$(Eq. 26). Each of the three polynomials is truncated to two terms. This regression only includes the heat capacity data, because it has been determined that the model calculations of VLE and heat of absorption are not sensitive to these parameters, so that it is not necessary to include them in the regression with the full set of data and parameters. Thus, these parameters are fixed at the values determined in this regression in the subsequent simultaneous regression.

The simultaneous data regression incorporates data for VLE ( $\mathrm{CO}_{2}$ and MEA partial pressure), heat capacity, and heat of absorption data for the ternary $\mathrm{MEA}-\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ system as well as additional VLE data for the binary MEA-H2O system. Due to the large number of parameters available for inclusion in the e-NRTL thermodynamic model, it is essential to include a parameter selection step in the model development methodology. Even with the simplified speciation model, given in Eqs. 27-28, there are approximately 60 parameters available for inclusion in the Gibbs free energy model. Parameter selection is necessary not only to avoid over-parameterization in the deterministic model, but to improve the computational feasibility of UQ. For the thermodynamic framework outlined previously, the Akaike Information Criterion (AIC) (Akaike, 1974) is used to determine the form of the final deterministic model. In this analysis, it is desired to minimize the AIC, so as to determine an optimal model to fit data without over-parameterization. The AIC may be expressed as:

$$
\begin{equation*}
A I C=N \ln \left(\frac{S S E}{N}\right)+2 k \tag{33}
\end{equation*}
$$

where $S S E$ refers to the sum of square error between data values and the model fit, $k$ is the number of parameters included in the model, and $N$ is the number of data included in the calibration of the model parameters.

The first regression is performed for a baseline model in which the parameters included are the reference temperature ( $25^{\circ} \mathrm{C}$ ) Gibbs free energy and enthalpy of formation of ionic species (represented as DGAQFM and DHAQFM in Aspen Plus) for species $\mathrm{MEA}^{+}$and $\mathrm{MEACOO}^{-}$and the parameters in the model for Henry's constant for the MEA- $\mathrm{H}_{2} \mathrm{O}$ pair. The Henry's constant parameters for the MEA- $\mathrm{H}_{2} \mathrm{O}$ binary pair are necessary because MEA is assumed to follow Henry's law in this work, similar to the Plaza model, and the solubility of MEA in $\mathrm{H}_{2} \mathrm{O}$ has not been well characterized in previous works. Therefore, the Henry parameters for this binary pair are treated as fitting parameters for the model. All NRTL molecule-molecule binary and electrolyte-molecule pair parameters are taken to be zero for this baseline model. Values for the parameters not mentioned here (e.g. pure component physical properties for MEA and $\mathrm{H}_{2} \mathrm{O}$ ) are taken from the library model available in Aspen Plus (Aspen Plus documentation, 2013a), and are not regressed in this work. In subsequent regressions, NRTL binary and pair parameters are added incrementally until the AIC is optimized.

\subsection*{2.4 Overview of UQ Methodology}

A methodology for developing physical property models with UQ is described in our previous work (Morgan et al., 2015), and a summary is given here. In the deterministic property model, the model output ( $\varphi$ ) is represented as a function of a set of predictor variables ( $\tilde{x}$ ) and a set of model parameters $(\tilde{\theta})$, denoted by:

$$
\begin{equation*}
\varphi=F(\tilde{x}, \tilde{\theta}) \tag{34}
\end{equation*}
$$


The model parameters are calibrated by fitting the model form to $M$ experimental data, denoted by:

$$
\begin{equation*}
Z=Z_{j}\left(\tilde{x}_{j}\right) \quad j=1,2, \ldots . M \tag{35}
\end{equation*}
$$


After developing the deterministic model, the stochastic model is created through the methodology shown schematically in Figure 1. Although this schematic is similar to that shown in Morgan et al. (2015), the technique for simultaneous sampling from the prior parameter distribution and the values of the predictor variables has been modified from the original version.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-16.jpg?height=1039&width=1441&top_left_y=294&top_left_x=328}
\captionsetup{labelformat=empty}
\caption{Figure 1: Overview of UQ for Physical Property Models}
\end{figure}

In the process of Bayesian inference, experimental data are used to update beliefs about the distribution of a set of parameters. A prior distribution is an initial distribution based on one's previous beliefs about the parameters. A posterior distribution is derived through Bayesian inference as an updated belief that takes the experimental data into account as evidence. In this work, a joint prior distribution, denoted as $P(\tilde{\theta})$ is assumed and a sample $\tilde{\theta}_{i}$ of size $N$ is taken. A sample $\tilde{x}_{i}$ of the predictor variables of interest is combined with the parameter sample, and the mathematical model is used to calculate the physical property value ( $\varphi_{i}$ ) for each set of parameters and predictor variables. A response surface model is created to map the input values of the parameters and predictor variables to the output physical property value, which results in a reduction in the computational cost of Bayesian inference. The function is replaced by an emulator, denoted as:

$$
\begin{equation*}
\varphi=F^{*}(\tilde{x}, \tilde{\theta}) \tag{36}
\end{equation*}
$$


In this work, a popular curve fitting method called multivariate adaptive regressions splines (MARS) (Friedman, 1991) is used to develop the response surfaces. Since thousands, if not more, simulations are required to estimate the posterior distributions, the use of surrogate response surfaces models in Bayesian inference applications is common practice, and many examples are available in the literature (e.g. Balakrishnan et al., 2003; Ma and Zabaras, 2009; Sudret, 2012; Bontinck et al., 2016). The advantages of response surface model based uncertainty quantification and the risks associated with inaccurate surrogate models, particularly those developed from an inadequate sample of true model observations, are described in the work of Giunta et al. (2006). Cross validation is used to assess the response surface quality, specifically to ensure that the surrogate response surface model is representative of the actual model without overfitting. The response surface model is expected to mimic the actual simulation model accurately, provided the cross validation test gives good results. The posterior distribution is computed by:

$$
\begin{equation*}
\pi(\tilde{\theta} \mid Z) \propto P(\tilde{\theta}) L(Z \mid \tilde{\theta}) \tag{37}
\end{equation*}
$$


Here, $P(\tilde{\theta})$ represents the prior distribution of the parameters and $\pi(\tilde{\theta} \mid Z)$ represents the posterior distribution. The likelihood funtion $L(Z \mid \tilde{\theta})$ measures the goodness of the match of the experimental data to the response surface model. If the response surface model fails to adequately emulate the actual model, the calculation of the likelihood function becomes less
valid and the updated parameter distribution may be inaccurate. The specific likelihood function used here is (Press et al., 1992):

$$
\begin{equation*}
L(Z \mid \tilde{\theta})=\exp \left(-0.5 \sum_{j=0}^{M} \frac{\left[F^{*}\left(\tilde{x}_{j}, \tilde{\theta}\right)-Z_{j}\left(\tilde{x}_{j}\right)\right]^{2}}{M \sigma_{j}^{2}}\right) \tag{38}
\end{equation*}
$$


The multivariate normal distribution is used as an initial prior distribution, which has a joint probability distribution function of the form (Hogg and Craig, 1978):

$$
\begin{equation*}
f(\tilde{\theta})=\frac{1}{(2 \pi)^{\frac{n}{2}}|\Sigma|^{\frac{1}{2}}} \exp \left\{-\frac{1}{2}(\tilde{x}-\tilde{\mu})^{T} \Sigma^{-1}(\tilde{x}-\tilde{\mu})\right\} \tag{39}
\end{equation*}
$$

where $\tilde{x}$ is a random vector of dimension $n$ with mean values $\tilde{\mu}$ and covariance matrix $\Sigma$. The posterior distribution is computed by the Markov Chain Monte Carlo (MCMC) method, which uses the Gibbs sampling method to accurately perform the parameter search (Beers, 2007). The posterior distribution $\pi(\tilde{\theta} \mid Z)$ is determined by Bayesian inference, and given in the form of a set of sample points.

\section*{3. Results and Discussions}

\subsection*{3.1 Deterministic Model Results}

\subsection*{3.1.1 Model Selection and Regression}

The values of the heat capacity polynomial parameters are presented in Table 2. Note that these parameters are fixed at these values for the simultaneous regression in which all data are included.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 2. Regressed values of heat capacity (J/kmol-K) polynomial parameters}
\begin{tabular}{|l|l|}
\hline Parameter & Value \\
\hline CPIG/1 (MEA) & $5.08 \times 10^{4}$ \\
\hline CPIG/2 (MEA) & 336 \\
\hline CPAQ/1 (MEACOO-) & -0.598 \\
\hline CPAQ/2 (MEACOO-) & 42.3 \\
\hline CPAQ/1 (MEA+) & $7.39 \times 10^{5}$ \\
\hline CPAQ/2 (MEA+) & $-1.63 \times 10^{3}$ \\
\hline
\end{tabular}
\end{table}

In the parameter selection methodology, the binary and pair NRTL parameters are incrementally included in the model regression to determine the optimal model based on the AIC values. The
results of this study are shown in Table 3. Here, the AIC values for the model with a given number of parameters correspond to the model with the lowest AIC for that number of parameters.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 3. Model AIC for varying number of NRTL parameters}
\begin{tabular}{|l|l|}
\hline Number of Parameters & AIC Value $\times 10^{-3}$ \\
\hline Baseline & 2.10 \\
\hline 1 & 1.91 \\
\hline 2 & 1.19 \\
\hline 3 & 1.16 \\
\hline 4 & 1.12 \\
\hline 5 & 1.13 \\
\hline
\end{tabular}
\end{table}

Since it has been determined that no five parameter model has an AIC lower than the four parameter model with the lowest AIC, this four parameter model is taken as the final deterministic model. The regression results are presented in the form of parameter values and standard deviations, shown in Table 4, and a matrix of correlation coefficients, shown in Table 5.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 4. Values of parameters included in thermodynamic framework}
\begin{tabular}{|l|l|l|l|}
\hline Parameter No. & Parameter Name & Value & Standard Deviation \\
\hline \multicolumn{4}{|c|}{Electrolyte Species Formation Parameters (MJ/kmol)} \\
\hline 1 & DGAQFM (MEA+) & -190 & 0.237 \\
\hline 2 & DGAQFM (MEACOO-) & -492 & 0.252 \\
\hline 3 & DHAQFM (MEA+) & -330 & 1.01 \\
\hline 4 & DHAQFM (MEACOO-) & -691 & 1.15 \\
\hline \multicolumn{4}{|c|}{Henry's Constant Parameters (Pa)} \\
\hline 5 & HENRY/1 (MEA- $\mathrm{H}_{2} \mathrm{O}$ ) & 28.6 & 0.183 \\
\hline 6 & HENRY/2 (MEA-H2O) & -7610 & 65.0 \\
\hline \multicolumn{4}{|c|}{NRTL Molecule-Molecule Binary Parameters} \\
\hline 7 & NRTL/1 (MEA- $\mathrm{H}_{2} \mathrm{O}$ ) & 3.25 & 0.196 \\
\hline 8 & NRTL/1 ( $\mathrm{H}_{2} \mathrm{O}$-MEA) & 4.34 & 0.481 \\
\hline 9 & NRTL/1 ( $\mathrm{CO}_{2}-\mathrm{H}_{2} \mathrm{O}$ ) & 69.4 & 4.18 \\
\hline 10 & NRTL/2 ( $\mathrm{H}_{2} \mathrm{O}$-MEA) & -2200 & 185 \\
\hline
\end{tabular}
\end{table}

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 5. Correlation coefficients of parameters in thermodynamic framework regression}
\begin{tabular}{|l|l|l|l|l|l|l|l|l|l|l|}
\hline & 1 & 2 & 3 & 4 & 5 & 6 & 7 & 8 & 9 & 10 \\
\hline 1 & 1 & & & & & & & & & \\
\hline 2 & -0.587 & 1 & & & & & & & & \\
\hline 3 & 0.388 & 0.0984 & 1 & & & & & & & \\
\hline 4 & 0.153 & 0.313 & -0.355 & 1 & & & & & & \\
\hline 5 & -0.335 & -0.396 & -0.540 & -0.415 & 1 & & & & & \\
\hline 6 & 0.344 & 0.398 & 0.540 & 0.418 & -0.998 & 1 & & & & \\
\hline 7 & -0.0401 & 0.337 & 0.276 & -0.0381 & -0.340 & 0.327 & 1 & & & \\
\hline 8 & -0.133 & -0.245 & -0.242 & -0.185 & 0.482 & -0.488 & -0.313 & 1 & & \\
\hline 9 & -0.147 & 0.0988 & -0.210 & 0.123 & $-2.29 \mathrm{e}-4$ & -5.16e-4 & 0.0160 & 0.00139 & 1 & \\
\hline 10 & 0.123 & 0.262 & 0.249 & 0.170 & -0.478 & 0.484 & 0.379 & -0.997 & -5.11e-5 & 1 \\
\hline
\end{tabular}
\end{table}

Table 4 shows the parameter values obtained from simultaneous regression. The electrolyte species formation parameters and Henry constant parameters are included as part of the baseline model and in all subsequent regressions. The set of four NRTL pair parameters included have been determined from the AIC analysis. Although electrolyte-molecule pair parameters have been considered in this analysis, none are included in the final model. This results in a substantial simplification to the model form, noting that of the three terms in the local contribution to the Gibbs free energy (Eq. 12), only the first remains in this model. By including this parameter selection methodology, it is shown that a reduced version of the e-NRTL model, containing a relatively small number of parameters, can adequately represent the thermodynamics of this system. By comparison, the model developed by Plaza (2012), which will be compared with this new model later in this work, included 41 regressed parameters.

\subsection*{3.1.2 Comparison of Experimental Data with Model Prediction}

The most widely available type of thermodynamic property data available in the open literature is ternary system VLE data, for which $\mathrm{CO}_{2}$ and MEA partial pressure values are available as a function of temperature, $\mathrm{CO}_{2}$ loading, and MEA weight percent. A summary of the $\mathrm{CO}_{2}$ partial pressure data considered in the model regression is given in Table 6. MEA partial pressure from Hilliard (2008) is also used, with the same number of data and variable ranges as given for $\mathrm{CO}_{2}$ partial pressure from this source.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 6. $\mathrm{CO}_{2}$ partial pressure data used in thermodynamic framework regression}
\begin{tabular}{|l|l|l|l|l|l|}
\hline Data Source & Number of Data & Temperature ( ${ }^{\circ} \mathrm{C}$ ) & Loading (mol CO2/MEA) & MEA weight percent & $\mathrm{CO}_{2}$ partial pressure (kPa) \\
\hline Aronu et al. (2011) & 138 & 40-80 & 0.017-0.565 & 15-45 & 0.0007-19 \\
\hline Hilliard (2008) & 55 & 40-60 & 0.114-0.591 & 17-40 & 0.005-50 \\
\hline Jou et al. (1995) & 46 & 25-120 & 0.003-0.589 & 30 & 0.0015-822 \\
\hline Dugas (2009) & 50 & 40-100 & 0.231-0.500 & 30-45 & 0.01-29 \\
\hline Lee et al. (1976) & 155 & 25-120 & 0.065-0.600 & 6.5-32 & 0.1-1000 \\
\hline Xu (2011) & 36 & 100-130 & 0.313-0.520 & 30 & 12-1000 \\
\hline Ma'mun et al. (2005) & 19 & 120 & 0.155-0.418 & 30 & 7-192 \\
\hline
\end{tabular}
\end{table}

The ranges of the input variables completely span, and in some cases exceed, the values of interest for industrial $\mathrm{CO}_{2}$ capture applications. Figure 2 shows a comparison of the ternary system $\mathrm{CO}_{2}$ partial pressure data to the models from Plaza (2012), the library of Aspen Plus (Aspen Plus documentation, 2013a), and this work (denoted as CCSI model).

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-24.jpg?height=995&width=1404&top_left_y=262&top_left_x=360}
\captionsetup{labelformat=empty}
\caption{Figure 2. Comparison of $\mathbf{C O}_{\mathbf{2}}$ partial pressure data from various sources for solutions of $\mathbf{3 0} \mathrm{wt} \% \mathrm{MEA}$ and temperatures of $(\mathrm{A}) \mathbf{4 0}^{\circ} \mathrm{C}$, (B) $\mathbf{8 0}^{\circ} \mathrm{C}$, and (C) $\mathbf{1 2 0}^{\circ} \mathrm{C}$ as a function of $\mathrm{CO}_{2}$ loading to new and existing models.}
\end{figure}

As shown in Figure 2, the fit of the CCSI model to these experimental data is adequate, and comparable to that of the Plaza model, despite the fact that a much smaller number of parameters is used. The fit is shown for the conditions for which the majority of the experimental are given, namely $30 \mathrm{wt} \%$ MEA and temperature values of $40^{\circ} \mathrm{C}, 80^{\circ} \mathrm{C}$, and $120^{\circ} \mathrm{C}$. Inset plots are included, on linear scale, for each temperature to clarify the fit of each model to the data at low values of loading. Temperatures of $40^{\circ} \mathrm{C}$ and $120^{\circ} \mathrm{C}$ correspond to typical operating conditions for the absorber and stripper, respectively. The Aspen Plus library model generally under predicts the data in the loading range below that of $0.6 \mathrm{~mol} \mathrm{CO}_{2} / \mathrm{mol} \mathrm{MEA}$. This is due to the fact this model's parameter regression considered a larger range of $\mathrm{CO}_{2}$ loading (approximately $0-1.4 \mathrm{~mol} \mathrm{CO}_{2} / \mathrm{mol} \mathrm{MEA}$ ), making the model accurate at higher loadings at the cost of reducing accuracy in the $\mathrm{CO}_{2}$ loading range that would be seen in typical industrial applications. No data with loading greater than $0.6 \mathrm{~mol} \mathrm{CO}_{2} / \mathrm{mol}$ MEA are included in the regression for this work, ensuring increased accuracy over the relevant operating region of the post-combustion carbon capture process.

For the binary MEA- $\mathrm{H}_{2} \mathrm{O}$ system, phase envelope data corresponding to a water mole fraction greater than 0.6 were included in the regression, noting that the baseline $30 \mathrm{wt} \% \mathrm{MEA}$ solution corresponds to 0.8 mole fraction of water. These data are included in the regression in order to better capture the limiting behavior of the system as the $\mathrm{CO}_{2}$ concentration approaches zero. The comparison of the models to these data is shown in Figure 3.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-26.jpg?height=1034&width=1586&top_left_y=292&top_left_x=266}
\captionsetup{labelformat=empty}
\caption{Figure 3. Comparison of phase envelope predictions to experimental data. T-xy data from Cai et al. (1996) are shown for fixed pressure of (A) 101.33 kPa and (B) 66.66 kPa . P-xy data from Tochigi et al. (1999) are shown at fixed temperature of (C) $\mathbf{3 6 3 . 1 5 ~ K}$.}
\end{figure}

Clearly, the Plaza (2012) model, which did not include these data in its parameter regression, gives an inadequate fit to the binary system data. By incorporating binary phase data in the new regression, the fit of the phase envelope data to the model improves markedly, particularly in the composition range of interest.

The fit of the heat of absorption data to the CCSI, Plaza (2012), and Aspen Plus library (Aspen Plus documentation, 2013a) models is shown in Figure 4. This includes differential heat of absorption data (Kim et al., 2014), which correspond to a solvent composition of $30 \mathrm{wt} \%$ MEA and temperature values of $40^{\circ} \mathrm{C}, 80^{\circ} \mathrm{C}$, and $120^{\circ} \mathrm{C}$.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-28.jpg?height=957&width=1492&top_left_y=262&top_left_x=268}
\captionsetup{labelformat=empty}
\caption{Figure 4. Heat of absorption data (Kim et al., 2014) for solutions of $30 \mathrm{wt} \%$ MEA and temperatures of $40^{\circ} \mathrm{C}, 80^{\circ} \mathrm{C}$, and $120^{\circ} \mathrm{C}$ as a function of $\mathrm{CO}_{2}$ loading compared to model predictions for (A) CCSI, (B) Plaza, and (C) Aspen Plus library models.}
\end{figure}

Here, it is shown that the temperature dependence of heat of absorption, as shown in the data, is not captured accurately in the Plaza model, which did not include the data in its regression. The fit of the data to this new model, however, clearly improves as a result of incorporating heat of absorption into the data regression through use of the FORTRAN user model. For the Aspen Plus library model, an earlier set of heat of absorption data (Kim and Svendsen, 2007) published by the same group as the data considered in this work, was included in the model regression. Although this model does capture the temperature dependence of the heat of absorption, it does not fit the new set of data as accurately as the CCSI model. The literature for the Aspen Plus library model (Aspen Plus documentation, 2013a) does not specify the details of its parameter regression, so it is unknown how the heat of absorption data were incorporated into the framework.

Finally, the heat capacity data included in the model regression (Weiland et al., 1997) correspond to a temperature of $25^{\circ} \mathrm{C}$ and solvent composition of $10-40 \mathrm{wt} \% \mathrm{MEA}$. The comparison of the CCSI and Plaza models to the experimental data is presented in Figure 5, and the fit is shown to be adequate for the model developed in this work. The fit of data to the Aspen Plus library model is omitted from the figure for the purpose of clarity, but this model also fits the data accurately, and comparably to the CCSI model.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-30.jpg?height=788&width=1443&top_left_y=285&top_left_x=313}
\captionsetup{labelformat=empty}
\caption{Figure 5. CCSI model and Plaza model predictions of heat capacity compared to data (Weiland et al., 1997 ) for solutions at $25^{\circ} \mathrm{C}$ for various values of MEA weight percent as a function of $\mathbf{C O}_{\mathbf{2}}$ loading.}
\end{figure}

In summary, Tables 7-8 give comparison of the fit of the three models described in this work to the major sources of data included in the regression in this work. Table 7 gives the sum of squared error (SSE) and Table 8 the values of the coefficient of determination ( $\mathrm{R}^{2}$ ) of the model with respect to each type of data. These values are calculated using the full set of experimental data incorporated into the regression for each data type. For this analysis, the values of $\mathrm{CO}_{2}$ partial pressure are calculated as $\ln \left(P_{\mathrm{CO}_{2}}\right)$.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 7. Values of SSE for models with respect to data included in the CCSI model regression}
\begin{tabular}{cccc}
\hline Data Type & CCSI Model & \begin{tabular}{c} 
Aspen Plus \\
Model
\end{tabular} Library & Plaza Model \\
\hline $\mathrm{CO}_{2}$ Partial Pressure & 131 & 1080 & 276 \\
Heat Capacity & 0.037 & 0.191 & 0.448 \\
Heat of Absorption & 460 & 727 & 994 \\
\hline
\end{tabular}
\end{table}

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 8. Values of $\mathbf{R}^{\mathbf{2}}$ for models with respect to data included in the CCSI model regression}
\begin{tabular}{cccc}
\hline Data Type & CCSI Model & \begin{tabular}{c} 
Aspen Plus ${ }^{(R)}$ Library \\
Model
\end{tabular} & Plaza Model \\
\hline $\mathrm{CO}_{2}$ Partial Pressure & 0.981 & 0.845 & 0.960 \\
Heat Capacity & 0.979 & 0.885 & 0.730 \\
Heat of Absorption & 0.925 & 0.882 & 0.838 \\
\hline
\end{tabular}
\end{table}

For each type of data, the overall SSE is lower for the new CCSI model in comparison to the existing models from Plaza and the Aspen Plus ${ }^{\circledR}$ library. Furthermore, all of the correlation coefficients between the model predictions and experimental data are highest for the CCSI model. Of all of the models, only the CCSI model has been regressed with all of the data used to calculate the statistics in Tables 7-8.

Analysis of variance (ANOVA) is used to determine the statistical significance of the fit of the model to the experimental data. Since the overall model is used to represent three distinct dependent variables, the test is performed for each, with the results given in Tables 9-11. For each test, the null hypothesis states that the model regressed in this work is not more predictive of a dependent variable ( $\varphi$ ) than a generic model ( $\varphi=\varphi_{0}$ ), where $\varphi_{0}$ is a constant value. The null hypothesis is rejected with at significance level $p$ under the condition that $F>F_{c}$ where F is
the calculated value of the F statistic and $F_{c}$ is the critical value, for $p$, of the F -distribution with degrees of freedom $k$ and $N-k-1$. Here, $k$ and $N$ refer to the number of parameters regressed and the number of data included of a given type, respectively. In Tables 9-11, DF, SS, and MS have their usual connotation. The values in Table 9 are calculated with respect to the transformed variable $\ln \left(P_{\mathrm{CO}_{2}}\right)$ to ensure that data observations with values of $P_{\mathrm{CO}_{2}}$ of large magnitude do not dominate the calculations.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 9. ANOVA table for regression ( $\mathbf{C O}_{\mathbf{2}}$ Partial Pressure)}
\begin{tabular}{cccccc}
\hline & DF & SS & MS & F & F $_{\text {c }}(\mathrm{p}=0.05)$ \\
\hline Model & 10 & 6827 & 683 & 2550 & 1.85 \\
Error & 488 & 131 & 0.268 & & \\
Total & 498 & 6958 & & & \\
\hline
\end{tabular}
\end{table}

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 10. ANOVA table for regression (Heat Capacity)}
\begin{tabular}{cccccc}
\hline & DF & SS & MS & F & $\mathrm{F}_{\mathrm{c}}(\mathrm{p}=0.05)$ \\
\hline Model & 10 & 1.658 & 0.166 & 62.2 & 2.67 \\
Error & 13 & 0.0347 & 0.00267 & & \\
Total & 23 & & & & \\
\hline
\end{tabular}
\end{table}

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 11. ANOVA table for regression (Heat of Absorption)}
\begin{tabular}{cccccc}
\hline & DF & SS & MS & F & F $_{\text {c }}(\mathrm{p}=0.05)$ \\
\hline Model & 10 & 6155 & 615 & 21.4 & 2.49 \\
Error & 16 & 460 & 28.8 & & \\
Total & 26 & 6615 & & & \\
\hline
\end{tabular}
\end{table}

For all three tests, the null hypothesis is rejected at a significance level $p=0.05$ since all calculated values of the $F$ statistic exceed the respective critical values.

\subsection*{3.2 Stochastic Modeling and Results}

The regression output given in Tables 4-5 is used to specify the hyperparameters (parameters of a prior distribution) for the UQ analysis; the means are taken directly and the covariance matrix is calculated from the matrix of correlation coefficients and the parameter standard deviations. A total of nine parameters are included in this distribution. The parameter denoted as No. 9 in Table 4 is eliminated from UQ analysis and set at a constant value, due to the fact that its
standard deviation is larger than the absolute value of its mean. Moreover, it has been determined that inclusion of this parameter while sampling from this distribution results in infeasible model output for many sample points.

For developing the stochastic model, a subset of the experimental data is chosen for inclusion in the Bayesian inference methodology. A representative subset of the data, rather than the full set of data, is used to reduce the computational expense of Bayesian inference. The $\mathrm{CO}_{2}$ partial pressure for $30 \mathrm{wt} \%$ MEA solutions at temperatures of $40^{\circ} \mathrm{C}, 80^{\circ} \mathrm{C}$, and $120^{\circ} \mathrm{C}$ and the full loading range ( $0.0001-0.6 \mathrm{~mol} \mathrm{CO}_{2} / \mathrm{mol} \mathrm{MEA}$ ) are chosen because a majority of the data are given at these conditions, and they are representative of the standard process conditions for $\mathrm{CO}_{2}$ capture applications. A sample of size 5000 is taken from the joint prior distribution and combined with a sample of the same size of $\mathrm{CO}_{2}$ loading values taken from a uniform distribution $(U(0.0001,0.6))$ corresponding to the range of interest. For each of the three temperature values of interest, this sample is propagated through the process simulation to calculate $\mathrm{CO}_{2}$ partial pressure. Some minor modifications to the prior distributions were carried out to ensure that the predicted ranges of the dependent variable cover the experimental data over the ranges of all independent variables of interest. The evaluation of $\mathrm{CO}_{2}$ partial pressure as a function of temperature and loading for the stochastic model is shown in Figure 6.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-34.jpg?height=1048&width=1539&top_left_y=257&top_left_x=279}
\captionsetup{labelformat=empty}
\caption{Figure 6: $\mathrm{CO}_{2}$ partial pressure prediction for stochastic model with a modified prior parameter distribution with experimental data for $\mathbf{3 0 ~ w t} \boldsymbol{\%}$ MEA at temperatures of (a) $40^{\circ} \mathrm{C}$, (b) $80^{\circ} \mathrm{C}$, and (c) $120^{\circ} \mathrm{C}$.}
\end{figure}

The Bayesian inference is performed by first developing the response surface model and then using it with the experimental data with their estimated standard deviation. For this procedure, the values of $P_{\mathrm{CO}_{2}}$ are transformed to $\ln \left(P_{\mathrm{CO}_{2}}\right)$ to improve the quality of the response surface model, particularly with respect to avoidance of negative partial pressure predictions. The accuracy of the response surface model is tested by a cross validation procedure, given that accurate estimation of the posterior distribution is contingent upon the use of a response surface that adequately emulates the original model. The results of this procedure are shown in Figure 7.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-36.jpg?height=592&width=1580&top_left_y=270&top_left_x=257}
\captionsetup{labelformat=empty}
\caption{Figure 7: Quality of response surface model for $\mathrm{CO}_{2}$ partial pressure. (A) Parity plot for cross validation ( $\mathbf{1 0}$-fold) of response surface model in comparison to simulation values. Values shown correspond to $\boldsymbol{\operatorname { l n }}\left(\boldsymbol{P}_{\boldsymbol{C O}_{2}}[\boldsymbol{k P A}]\right)$. (B) Ratio of response surface predictions to simulation values for $\mathrm{CO}_{2}$ partial pressure (without logarithmic transformation) as a function of $\mathbf{C O}_{\mathbf{2}}$ loading.}
\end{figure}

As shown in Figure 7, the response surface developed with MARS serves as an effective surrogate for the actual model, and the actual simulation values and response surface values are correlated with a value of $R^{2}=0.9983$. From Figure 7B, it is observed that the response surface model has higher error at very low ( $<0.01$ ) values of lean loading. However, it has minimal effect on the results from the Bayesian UQ since the experimental data at such extreme low levels are scarce and not used in the Bayesian inference. Furthermore, it should be noted that process operation at such a low value of lean loading is generally impractical due to the large cost associated with the energy input into the stripper reboiler, and operation below 0.1 mol $\mathrm{CO}_{2}$ /MEA is generally not recommended (Kohl and Nielsen, 1997). In replacing the full thermodynamic model with the response surface model, the computational cost associated with running thousands of Aspen Plus ${ }^{\circledR}$ simulations to evaluate $\mathrm{CO}_{2}$ partial pressure as a function of the model parameters and predictor variables is greatly reduced.

The prior and posterior distributions are fully represented by a 9 parameter joint distribution that cannot be visualized readily, although some representation of the change in the parameter distribution resulting from UQ is shown in Figures 8 and 9. Single parameter marginal distributions for all parameters are shown in Figure 8 and selected examples of two parameter marginal distributions are shown in Figure 9. For the purpose of clarity, the distributions shown in Figures 8-9 are for normalized parameter values; the value of each parameter $\theta_{i}$ is replaced by a normalized value:

$$
\begin{equation*}
\theta_{i}^{*}=\frac{\theta_{i}}{\hat{\theta}_{i}} \tag{40}
\end{equation*}
$$

where $\widehat{\theta}_{i}$ is the deterministic model value for the given parameter, as given in Table 4.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-38.jpg?height=880&width=1335&top_left_y=302&top_left_x=412}
\captionsetup{labelformat=empty}
\caption{Figure 8: Single parameter marginal probability density functions for prior and posterior distributions. Red and blue lines represent prior and posterior distributions, respectively, and parameter numbers match those given in Table 4. Parameter values are normalized by dividing by the deterministic value of the respective parameter.}
\end{figure}

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-39.jpg?height=1140&width=1498&top_left_y=283&top_left_x=296}
\captionsetup{labelformat=empty}
\caption{Figure 9: Normalized prior and posterior two-parameter marginal distributions for (A) parameters 1 and 2 and (B) parameters 5 and 6.}
\end{figure}

Although Figures 8 and 9 do not show the complete effect of Bayesian inference on the parameter distribution, the change in some of the parameter values is evident. For the prior distribution, the single parameter marginal distributions all have the shape of a normal distribution, given that the multivariate normal distribution is chosen as the form of the prior. The marginal posterior distributions, however, are estimated from a sample of points obtained at the end of the UQ algorithm, and thus are not given in the form of any standard type of distribution. The shapes of the marginal distributions vary by parameter. For some parameters, the value of maximum probability density changes significantly (e.g. Parameter 1) as shown in the shift in the probability distribution function (pdf). The change in this parameter's distribution is also shown by the shift in probability density in Figure 9A. In the joint marginal distribution for the two Henry's constant parameters (Figure 9B), the region of maximum probability density is also shifted and spans over a much smaller region.

The effect of Bayesian inference on the parameter distribution is visualized more clearly by propagating a sample of the posterior distribution through the thermodynamic model and comparing with the result obtained with the prior distribution using a sample of size 5000 , which is used to evaluate the $\mathrm{CO}_{2}$ partial pressure as a function of temperature and $\mathrm{CO}_{2}$ loading, and the results are shown in Figure 10.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-41.jpg?height=1038&width=1584&top_left_y=262&top_left_x=279}
\captionsetup{labelformat=empty}
\caption{Figure 10: CO2 partial pressure prediction for stochastic model with a posterior parameter distribution with experimental data for $30 \mathrm{wt} \%$ MEA at temperatures of (a) $40^{\circ} \mathrm{C}$, (b) $80^{\circ} \mathrm{C}$, and (c) $120^{\circ} \mathrm{C}$.}
\end{figure}

The ranges of $\mathrm{CO}_{2}$ partial pressure predicted by the stochastic model with the posterior distribution are generally smaller than those predicted by the model with the prior distribution. This is expected, as relatively infeasible parameter space is removed from the distribution as a result of Bayesian inference. Moreover, the majority of the data fall within the range predicted by the model, which is a desirable outcome of Bayesian inference.

\subsection*{3.3 Case Studies with $\mathbf{C O}_{\mathbf{2}}$ Capture Process}

The thermodynamic and reaction kinetics models are incorporated into the process model developed in the work of Plaza (2012) using Aspen Plus V8.4. Absorber and stripper columns are modeled as rate-based towers using the RadFrac unit operation. The thermodynamic model is incorporated through the built-in ELECNRTL physical property method, and the reaction kinetics model is inserted into the simulation through a FORTRAN user model as discussed earlier.

To determine the effect of the thermodynamic uncertainty on the MEA-based CO2 capture process, case studies are performed in which prior and posterior distributions are propagated through absorber and regenerator process models. For the absorber, two cases are considered and the model variables for these cases are summarized in Table 12. All variables, with the exception of $\mathrm{CO}_{2}$ capture percentage, are input variables to the simulation.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 12. Variables for Absorber Case Studies}
\begin{tabular}{|l|l|l|}
\hline Model Variable & Case 1 & Case 2 \\
\hline Inlet Solvent Flowrate (kg/hr) & 3000 & 4000 \\
\hline Inlet Gas Flowrate (kg/hr) & 680 & 680 \\
\hline Inlet Solvent Temperature ( ${ }^{\circ} \mathrm{C}$ ) & 40 & 40 \\
\hline Inlet Solvent Pressure (kPa) & 101.325 & 101.325 \\
\hline Inlet Solvent MEA wt\% & 35.5 & 35.5 \\
\hline Inlet Solvent Loading ( $\mathrm{mol} \mathrm{CO}_{2} / \mathrm{MEA}$ ) & 0.35 & 0.35 \\
\hline CO2 Capture Percentage & 76.76 & 90.05 \\
\hline
\end{tabular}
\end{table}

One thousand samples are randomly drawn from both the posterior and prior distributions and propagated through the simulations as summarized in Table 12. The $\mathrm{CO}_{2}$ capture percentage is calculated for each simulation, and the pdfs corresponding to the prior and posterior distributions for each case are shown in Figure 11.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-43.jpg?height=549&width=1507&top_left_y=266&top_left_x=285}
\captionsetup{labelformat=empty}
\caption{Figure 11: Pdfs for $\mathbf{C O}_{\mathbf{2}}$ capture percentage for stochastic absorber models for (A) Case 1 and (B) Case 2}
\end{figure}

In Figure 11, the sharper peaks corresponding to the posterior distribution for each of the two cases indicate that the most likely value of $\mathrm{CO}_{2}$ capture can be estimated more precisely as a result of performing the Bayesian inference methodology. Additionally, the range of $\mathrm{CO}_{2}$ capture predicted by the stochastic model with the posterior distribution is smaller compared to that predicted by the model with the prior distribution.

A similar analysis is performed for the stripper. Model variables for two cases are shown in Table 13. For this simulation, the output variable is the loading of the rich solvent at the stripper outlet. All other variables are input variables.

\begin{table}
\captionsetup{labelformat=empty}
\caption{Table 13. Variables for Regenerator Case Studies}
\begin{tabular}{|l|l|l|}
\hline Model Variable & Case 1 & Case 2 \\
\hline Inlet Solvent Flowrate (kg/hr) & 3100 & 3100 \\
\hline Inlet Solvent Temperature ( ${ }^{\circ} \mathrm{C}$ ) & 106.5 & 106.5 \\
\hline Inlet Solvent Pressure (kPa) & 230.4 & 230.4 \\
\hline Inlet Solvent MEA wt\% & 35.5 & 35.5 \\
\hline Inlet Solvent Loading (mol CO2/MEA) & 0.5 & 0.3 \\
\hline Reboiler Duty (kW) & 140 & 400 \\
\hline Outlet Solvent Loading (mol CO2/MEA) & 0.2982 & 0.0907 \\
\hline
\end{tabular}
\end{table}

One thousand samples are randomly drawn from both the posterior and prior distributions and propagated through the simulations described in Table 13. The lean loading is calculated for each simulation, and the pdfs corresponding to the prior and posterior distributions for each case are shown in Figure 12.

\begin{figure}
\includegraphics[alt={},max width=\textwidth]{https://cdn.mathpix.com/cropped/e5feef31-13d5-4857-aac7-439552afe01b-45.jpg?height=542&width=1535&top_left_y=268&top_left_x=300}
\captionsetup{labelformat=empty}
\caption{Figure 12: Pdfs for predicted lean solvent loading for stochastic regenerator models for (A) Case 1 and (B) Case 2}
\end{figure}

The general effect of Bayesian inference on the rich loading prediction is that the interval of feasible values becomes smaller and the probability density of the most likely value, given by the peak of the distribution, becomes higher. This trend is more pronounced for the lower loading case given in Figure 12. As expected, in comparison to the uncertainty in the stochastic models for viscosity, density, and surface tension of this system developed in our previous work (Morgan et al., 2015), the uncertainty in the thermodynamic framework is shown to have a relatively large effect on the performance of the process model. This implies that the solventbased $\mathrm{CO}_{2}$ capture process is more highly sensitive to the thermodynamic framework compared to the other physical property models for the system.

\section*{4. Conclusions}

In this work, deterministic and stochastic models of the thermodynamics of the MEA- $\mathrm{H}_{2} \mathrm{O}-\mathrm{CO}_{2}$ system have been developed using a rigorous methodology that is widely applicable to physical property modeling for a wide range of systems. The deterministic model incorporates data for VLE, heat capacity, and heat of absorption that span the temperature and composition ranges of interest for the industrial $\mathrm{CO}_{2}$ capture process into the e-NRTL thermodynamic framework. Moreover, the reaction kinetics are represented in a form that ensures consistency with the thermodynamic model. A parameter selection methodology using the AIC has been applied to determine an optimal set of parameters for representing the thermodynamic model. Through this approach, it has been determined that only a small subset of the parameters available in the eNRTL model is required to accurately represent the data in a thermodynamically consistent manner.

Due to the reduced parameterization of the thermodynamic model, it is computationally feasible to perform uncertainty quantification through a Bayesian inference methodology. Thus, a stochastic model of the process was developed. Case studies are performed to determine the effect of the parametric uncertainty determined in this work on the results of absorber and regenerator simulations. Probability distributions of quantities of interest, percentage of $\mathrm{CO}_{2}$ capture by the absorber and $\mathrm{CO}_{2}$ loading in the outlet solvent from the regenerator, are obtained by propagating distributions from the thermodynamic model parameter space through the absorber and regenerator process models. In comparison with those obtained in our previous work on the uncertainty of viscosity, density, and surface tension submodels, the effects resulting
from the propagation of the thermodynamic model uncertainty are significantly larger. This study demonstrates that the solution thermodynamic models of a solvent-based $\mathrm{CO}_{2}$ capture system are a major source of uncertainty that should be considered for a rigorous analysis of the system.

Finally it should be noted that for accurate estimation of the performance of the MEA-based CO2 capture process, not only the thermodynamic and kinetic models but also other submodels such as the mass transfer and hydraulic models are crucial. After these models are developed with uncertainty quantification, a complete sensitivity analysis can be performed for the system in which the parametric uncertainty from all submodels is propagated throughout the complete process model simultaneously. With these results, effects of parametric uncertainty from various submodels (e.g. VLE, mass transfer) can be compared under different operating regimes. The authors look forward to presenting such a study in the near future.

\section*{Acknowledgement}

This research was conducted through the Carbon Capture Simulation Initiative (CCSI), funded through the U.S. DOE Office of Fossil Energy. A portion of this work was funded by Lawrence Berkeley Laboratory through contract\# 7210843. The authors would like to thank Prof. Gary T. Rochelle from The University of Texas at Austin for sharing the Phoenix model. The authors sincerely acknowledge valuable discussions with Prof. Rochelle and Brent Sherman from The University of Texas at Austin.

\section*{Disclaimer}

This paper was prepared as an account of work sponsored by an agency of the United States Government. Neither the United States Government nor any agency thereof, nor any of their employees, makes any warranty, express or implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, product, or process disclosed, or represents that its use would not infringe privately owned rights. Reference herein to any specific commercial product, process, or service by trade name, trademark, manufacturer, or otherwise does not necessarily constitute or imply its endorsement, recommendation, or favoring by the United States Government or any agency thereof. The views
and opinions of authors expressed herein do not necessarily state or reflect those of the United States Government or any agency thereof.

\section*{Literature Cited}

Akaike, H., 1974. A new look at the statistical model identification. IEEE Trans. Autom. Control. 19 (6), 716-723.

Amundsen, T.G., Lars, E.Ø., Eimer, D.A., 2009. Density and viscosity of monoethanolamine + water + carbon dioxide from (25 to 80) ${ }^{\circ}$. J. Chem. Eng. Data. 54 (11), 3096-3100.

Aronu, U.E., Gondal, S., Hessen, E.T., Haug-Warberg, T., Hartono, A., Hoff, K.A., Svendsen, H.F., 2011. Solubility of $\mathrm{CO}_{2}$ in $15,30,45$, and 60 mass $\% \mathrm{MEA}$ from 40 to $120^{\circ} \mathrm{C}$ and model representation using the extended UNIQUAC framework. Chem. Eng. Sci. 66 (24), 6393-6406.

Aspen Plus documentation, 2013a. Rate-based Model of the $\mathrm{CO}_{2}$ Capture Process by MEA Using Aspen Plus, V8.4. Aspen Technology, Inc., Cambridge, MA.

Aspen Plus documentation, 2013b. Physical Property System: Physical Property Methods, V8.4. Aspen Technology, Inc., Cambridge, MA.

Aspen Plus documentation, 2013c. Physical Property System: Physical Property Models, V8.4. Aspen Technology, Inc., Cambridge, MA.

Balakrishnan, S., Roy, A., Ierapetritou, M.G., Flach, G.P., Georgopoulos, P.G., 2003. Uncertainty reduction and characterization for complex environmental fate and transport models: an empirical Bayesian framework incorporating the stochastic response surface method. Water Resour. Res. 39 (12), article 1350.

Beers, K.J., 2007. Probability theory and stochastic simulation, in: Numerical Methods for Chemical Engineering: Applications in MATLAB ${ }^{\circledR}$. Cambridge University Press, New York, pp. 372-435.

Bontinck, Z., De Gersem, H., Schöps, S., 2016. Response surface models for the uncertainty quantification of eccentric permanent magnet synchronous machines. IEEE T. Magn. 52 (3), article 72030404.

Cai, Z., Xie, R., Wu, Z., 1996. Binary isobaric vapor-liquid equilibria of ethanolamines + water. J. Chem. Eng. Data. 41 (5), 1101-1103.

Chen, C.C., Britt, H.I., Boston, J.F., Evans, L.B., 1982. Local composition model for excess Gibbs energy of electrolyte systems part 1: single solvent, single completely dissociated electrolyte systems. AIChE J. 28 (4), 588-596.

Dugas, R.E., 2009. Carbon Dioxide Absorption, Desorption, and Diffusion in Aqueous Piperazine and Monoethanolamine. Ph.D. Thesis. The University of Texas at Austin, 2009.

Friedman, J.H., 1991. Multivariate adaptive regression splines. Ann. Stat. 19 (1), 1-141.
Gel, A., Li, T., Gopalan, B., Shahnam, M., Syamlal, M., 2013. Validation and uncertainty quantification of a multiphase computational fluid dynamics model. Ind. Eng. Chem. Res. 52 (33), 11424-11435.

Gel, A., Chaudhari, K., Turton, R., Nicoletti, P., 2014. Application of uncertainty quantification methods for coal devolatilization kinetics in gasifier modeling. Powder Technol. 265, 66-75.

Giunta, A.A., McFarland, J.M., Swiler, L.P., Eldred, M.S., 2006. The promise and peril of uncertainty quantification using response surface approximations. Struct. Infrastruct. E. 2 (3-4), 175-189.

Han, B., Zhou, C., Wu, J., Tempel, D.J., Cheng, H., 2011. Understanding $\mathrm{CO}_{2}$ capture mechanisms in aqueous monoethanolamine via first principles simulations. J. Phys. Chem. Lett. 2 (6), 522-526.

Hilliard, M.D., 2008. A Predictive Thermodynamic Model for an Aqueous Blend of Potassium Carbonate, Piperazine, and Monoethanolamine for Carbon Dioxide Capture from Flue Gas. Ph.D. Thesis. The University of Texas at Austin.

Hogg, R.V., Craig, A.T., 1978. The multivariate normal distribution, in: Introduction to Mathematical Statistics, fourth ed. Macmillan Publishing Co., Inc., New York, pp. 405-410.

Jayarathna, S.A., Weerasooriya, A., Dayarathna, S., Eimer, D.A., Melaaen, M.C., 2013. Densities and surface tensions of $\mathrm{CO}_{2}$ loaded aqeous monoethanolamine solutions with $\mathrm{r}=(0.2$ to 0.7 ) at $\mathrm{T}=(303.15$ to 333.15)K. J. Chem. Eng. Data. 58 (4), 986-992.

Jou, F.Y., Mather, A.E., Otto, F.D., 1995. The solubility of $\mathrm{CO}_{2}$ in a 30 mass percent monoethanolamine solution. Can. J Chem. Eng. 73 (1), 140-147.

Kaewsichan, L., Al-Bofersen, O., Yesavage, V.F., Selim, M.S., 2001. Predictions of the solubility of acid gases in monoethanolamine (MEA) and methyldiethanolamine (MDEA) solutions using the electrolyte-UNIQUAC model. Fluid Phase Equilibr. 183-184, 159-171.

Kim, I., Svendsen, H.F., 2007. Heat of absorption of carbon dioxide ( $\mathrm{CO}_{2}$ ) in monoethanolamine (MEA) and 2-(Aminoethyl) ethanolamine (AEEA) solutions. Ind. Eng. Chem. Res. 46 (17), 5803-5809.

Kim, I., Hoff, K.A., Mejdell, T., 2014. Heat of absorption of $\mathrm{CO}_{2}$ with aqueous solutions of MEA: new experimental data. Energy Procedia. 63, 1446-1455.

Kohl, A.L., Nielsen, R., 1997. Mechanical design and operation of alkanolamine plants, in: Gas Purification, fifth ed. Gulf Publishing Company, Houston, TX, pp. 187-277.

Lane, W.A., Storlie, C.B., Montgomery, C.J., Ryan, E.M., 2014. Numerical modeling and uncertainty quantification of a bubbling fluidized bed with immersed horizontal tubes. Powder Technol. 253, 733-743.

Lee, J.I., Otto, F.D., Mather, A.E., 1976. Equilibrium between carbon dioxide and aqueous monoethanolamine solutions. J. Appl. Chem. Biotechn. 26 (1), 541-549.

Ma, Z., Zabaras, N., 2009. An efficient Bayesian inference approach to inverse problems based on adaptive sparse grid collection method. Inverse Probl. 25(3), article 035013.

Ma'mun, S., Nilsen, R., Svendsen, H.F., 2005. Solubility of carbon dioxide in 30 mass\% monoethanolamine and 50 mass\% methyldiethanolamine solutions. J. Chem. Eng. Data. 50 (2), 630-634.

Mathias, P.M., 2014. Sensitivity of process design to phase equilibrium- a new perturbation method based upon the Margules equation. J. Chem. Eng. Data. 59 (4), 1006-1015.

Mathias, P.M., Gilmartin, J.P., 2014. Quantitative evaluation of the effect of uncertainty in property models on the simulated performance of solvent-based $\mathrm{CO}_{2}$ capture. Energy Procedia. 63, 1171-1185.

Mebane, D.S., Bhat, K.S., Kress, J.D., Fauth, D.J., Gray, M.L., Lee, A., Miller, D.C., 2013. Bayesian calibration of thermodynamic models for the uptake of $\mathrm{CO}_{2}$ in supported amine sorbents using ab initio priors. Phys. Chem. Chem. Phys. 15, 4355-4366.

Miller, D.C., Syamlal M., Mebane, D.S., Storlie C., Bhattacharyya D., Sahinidis N.V., Agarwal D., Tong C., Zitney S.E., Sarkar A., Sun X., Sundaresan S., Ryan E., Engel D., Dale C., 2014. Carbon capture simulation initiative: a case study in multiscale modeling and new challenges. Annu. Rev. Chem. Biomol. Eng. 5, 301-323.

Mišković, L., Hatzimanikatis, V., 2011. Modeling of uncertainties in biochemical reactions. Biotechnol. Bioeng. 108 (2), 413-423.

Morgan, J.C., Bhattacharyya, D., Tong, C., Miller, D.C., 2015. Uncertainty quantification of property models: methodology and its application to $\mathrm{CO}_{2}$-loaded aqueous MEA solutions. AIChE J. 61 (6), 1822-1839.

Papadimitriou, C., 2014. Bayesian uncertainty quantification and propagation in structural dynamics simulations. Paper presented at International Conference on Structural Dynamics, Porto, Portugal.

Plaza, J.M., 2012. Modeling of Carbon Dioxide Absorption Using Aqueous Monoethanolamine, Piperazine, and Promoted Potassium Carbonate. Ph.D. Thesis. The University of Texas at Austin.

Press, W.H., Teukolsky, S.A., Vetterling, W.T., Flannery, B.P., 1992. Modeling of data, in: Numerical Recipes in C: the Art of Scientific Computing, second ed. Cambridge University Press, New York, pp. 656-706.

Sarkar, S., Kosson, D.S., Mahadevan, S., Meeussen, J.C., van der Sloot, H., Arnold, J.R., Brown, K.G., 2012. Bayesian calibration of thermodynamic parameters for geochemical speciation modeling of cementitious materials. Cem. Concr. Res. 42 (7), 889-902.

Sudret, B., 2012. Meta-models for structural reliability and uncertainty quantification. Paper presented at Fifth Asian-Pacific Symposium on Structural Reliability and its Applications, Singapore.

Tochigi, K., Akimoto, K., Ochi, K., Liu, F., Kawase, Y., 1999. Isothermal vapor-liquid equilibria for water +2 -aminoethanol + dimethyl sulfoxide and its constituent three binary systems. J. Chem. Eng. Data. 44 (3), 588-590.

Vrachnos, A., Kontogeorgis, G., Voutsas, E., 2006. Thermodynamic modeling of acidic gas solubility in aqueous solutions of MEA, MDEA, and MEA-MDEA blends. Ind. Eng. Chem. Res. 45 (14), 5148-5154.

Weber, C.L., Vanbriesen, J.M., Small, M.S., 2006. A stochastic regression approach to analyzing thermodynamic uncertainty in chemical speciation modeling. Environ. Sci. Technol. 40 (12), 3872-3878.

Weiland, R.H., Dingman, J.C., Cronin, D.B., 1997. Heat capacity of aqueous monoethanolamine, diethanolamine, n-methyldiethanolamine, and n-methyldiethanolamine-based blends with carbon dioxide. J. Chem. Eng. Data. 42 (5), 1004-1006.

Whiting, W.B., 1996. Effects of uncertainties in thermodynamic data and models on process calculations. J. Chem. Eng. Data. 41 (5), 935-941.

Xu, Q., 2011. Thermodynamics of $\mathrm{CO}_{2}$ loaded Aqueous Amines. Ph.D. Thesis. The University of Texas at Austin.

Yu, Y.S., Lu, H.F., Wang, G.X., Zhang, Z.X., Rudolph, V., 2013. Characterizing the transport properties of multiamine solutions for $\mathrm{CO}_{2}$ capture by molecular dynamics simulation. J. Chem. Eng. Data. 58 (6), 1429-1939.

Zhang, Y., Que, H., Chen, C.C., 2011. Thermodynamic modeling for CO2 absorption in aqueous MEA solution with electrolyte NRTL model. Fluid Phase Equilibr. 311, 67-75.